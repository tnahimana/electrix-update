<?php

namespace App\Console\Commands;

use App\Http\Livewire\Dashboard\UserDashboard;
use Illuminate\Console\Command;

class RunLivewireFunction extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'livewire:run-function';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Create an instance of your Livewire component
        $component = new UserDashboard();

        // Call the desired method on the Livewire component
        $component->processTransactions();

        // Output a message for logging/debugging
        $this->info('Livewire function executed successfully.');
    }
}