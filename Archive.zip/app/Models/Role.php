<?php

namespace App\Models;

use App\Models\Admins;
use App\Models\Agents;
use App\Models\Clients;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Role extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function admin(){
        return $this->hasOne(Admins::class);
    }

    public function client(){
        return $this->hasOne(Clients::class);
    }

    public function agent(){
        return $this->hasOne(Agents::class);
    }

}