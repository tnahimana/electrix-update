<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PaymentTransaction extends Model
{
    use HasFactory;

    protected $guarded = [];

    public static function search($search)
    {
        return empty($search) ? static::query() : static::query()->where('id', 'like', '%' . $search . '%')
            ->orWhere('phone', 'like', '%' . $search . '%')
            ->orWhere('reg_meter', 'like', '%' . $search . '%')
            ->orWhere('electrix_meter', 'like', '%' . $search . '%')
            ->orWhere('trx_state', 'like', '%' . $search . '%')
            ->orWhere('sms_status', 'like', '%' . $search . '%');
    }
}