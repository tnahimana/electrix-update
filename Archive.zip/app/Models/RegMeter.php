<?php

namespace App\Models;

use App\Models\Cell;
use App\Models\Sector;
use App\Models\Village;
use App\Models\District;
use App\Models\Province;
use App\Models\Clients;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class RegMeter extends Model
{
    use HasFactory;

    protected $guarded = [];

    public static function search($search){
        return empty($search) ? static::query() : static::query()->where('id','like','%'.$search.'%')
                ->orWhere('client_id','like','%'.$search.'%')
                ->orWhere('land_upi','like','%'.$search.'%')
                ->orWhere('reg_meter_number','like','%'.$search.'%')
                ->orWhere('meter_street_address','like','%'.$search.'%');
    }

    public function province(){
        return $this->belongsTo(Province::class, 'meter_province_id');
    }

    public function district(){
        return $this->belongsTo(District::class, 'meter_district_id');
    }

    public function sector(){
        return $this->belongsTo(Sector::class, 'meter_sector_id');
    }

    public function cell(){
        return $this->belongsTo(Cell::class, 'meter_cell_id');
    }

    public function village(){
        return $this->belongsTo(Village::class, 'meter_village_id');
    }

    public function client()
    {
        return $this->belongsTo(Clients::class, 'client_id');
    }

}