<?php

namespace App\Models;

use App\Models\RegMeter;
use App\Models\MobileUser;
use App\Models\ElectrixMeter;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Sale extends Model
{
    use HasFactory;

    protected $guarded = [];

    public static function search($search){
        return empty($search) ? static::query() : static::query()->where('id','like','%'.$search.'%')
                ->orWhere('mobile_user_id','like','%'.$search.'%')->with('mobileuser')
                ->orWhere('reg_meter_id','like','%'.$search.'%')->with('regmeter')
                ->orWhere('electrix_meter_id','like','%'.$search.'%')->with('electrixmeter')
                ->orWhere('initial_cost','like','%'.$search.'%')
                ->orWhere('initial_cost','like','%'.$search.'%')
                ->orWhere('reg_meter_token','like','%'.$search.'%')
                ->orWhere('electrix_meter_token','like','%'.$search.'%')
                ->orWhere('units','like','%'.$search.'%');
    }

    public function mobileuser(){
        return $this->belongsTo(MobileUser::class, 'mobile_user_id');
    }

    public function regmeter(){
        return $this->belongsTo(RegMeter::class, 'reg_meter_id');
    }

    public function electrixmeter(){
        return $this->belongsTo(ElectrixMeter::class, 'electrix_meter_id');
    }
}