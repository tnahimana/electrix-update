<?php

namespace App\Models;

use App\Models\RegMeter;
use App\Models\WasacMeter;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ElectrixMeter extends Model
{
     use HasFactory;

    protected $guarded = [];

    public function mainMeter(){
        return $this->belongsTo(RegMeter::class);
    }

    public function regmeter(){
        return $this->belongsTo(RegMeter::class,'reg_meter_id');
    }

    public function wasacmeter(){
        return $this->belongsTo(WasacMeter::class,'wasac_meter_id');
    }

    public static function search($search){
        return empty($search) ? static::query() : static::query()->where('id','like','%'.$search.'%')
                ->orWhere('reg_meter_id','like','%'.$search.'%')
                ->orWhere('electrix_meter_number','like','%'.$search.'%');
    }
    
}