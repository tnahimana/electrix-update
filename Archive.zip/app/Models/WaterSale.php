<?php

namespace App\Models;

use App\Models\ElectrixMeter;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class WaterSale extends Model
{
    use HasFactory;

    protected $guarded = [];

    public static function search($search){
        return empty($search) ? static::query() : static::query()->where('id','like','%'.$search.'%')
                ->orWhere('mobile_user_id','like','%'.$search.'%')
                ->orWhere('wasac_meter_id','like','%'.$search.'%')
                ->orWhere('electrix_meter_id','like','%'.$search.'%')
                ->orWhere('token_cost','like','%'.$search.'%')
                ->orWhere('units','like','%'.$search.'%')
                ->orWhere('water_meter_token','like','%'.$search.'%');
    }

    public function electrixmeter(){
        return $this->belongsTo(ElectrixMeter::class, 'electrix_meter_id');
    }

    public function wasacmeter(){
        return $this->belongsTo(WasacMeter::class, 'wasac_meter_id');
    }

    public function mobileuser(){
        return $this->belongsTo(MobileUser::class, 'mobile_user_id');
    }
}