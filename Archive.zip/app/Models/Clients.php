<?php

namespace App\Models;

use App\Models\Role;
use App\Models\Image;
use App\Models\Address;
use App\Models\Document;
use App\Models\RegMeter;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Clients extends Model
{
    use HasFactory;

    protected $guarded = [];

    public static function search($search){
        return empty($search) ? static::query() : static::query()->where('id','like','%'.$search.'%')
                ->orWhere('firstname','like','%'.$search.'%')
                ->orWhere('middlename','like','%'.$search.'%')
                ->orWhere('lastname','like','%'.$search.'%')
                ->orWhere('email','like','%'.$search.'%')
                ->orWhere('phone','like','%'.$search.'%');
    }

    public function role(){
        return $this->belongsTo(Role::class);
    }

    public function document(){
        return $this->belongsTo(Document::class);
    }

    public function address(){
        return $this->belongsTo(Address::class);
    }

    public function image(){
        return $this->belongsTo(Image::class);
    }

    public function regMeter(){
        return $this->hasMany(RegMeter::class,'client_id');
    }
}
