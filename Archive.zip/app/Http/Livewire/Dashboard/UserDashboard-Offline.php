<?php

namespace App\Http\Livewire\Dashboard;

use Carbon\Carbon;
use App\Models\Sale;
use Livewire\Component;
use App\Models\RegMeter;
use App\Models\MobileUser;
use App\Models\WasacMeter;
use App\Models\ElectrixMeter;
use InvalidArgumentException;
use App\Models\FdiTransaction;
use PhpParser\Node\Stmt\Else_;
use App\Models\VendTransaction;
use Illuminate\Validation\Rule;
use App\Models\NewApiTransaction;
use Faker\Provider\ar_EG\Payment;
use PhpParser\Node\Stmt\TryCatch;
use App\Models\PaymentTransaction;
use App\Models\TransactionReclaim;
use App\Models\WaterSale;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Http\Client\RequestException;

class UserDashboard extends Component
{
    public $energy = false;
    public $water = false;
    public $token = false;
    public $electrix_meter;
    public $electrix_meters = [];
    public $meterNumber;
    public $amount;
    public $mobile_user = 36;
    public $data;
    public $phone;
    public $payment;
    public $meterOwner;
    public $regMeter;
    public $trxId;
    public $confirmed = false;
    public $retrieveDataTrx;
    public $wallet_balance;
    public $errorStatus = false;
    public $reg_meters = [];
    public $water_meters = [];
    public $water_meter;
    public $meter;
    public $search_type;
    public $meters = [];
    public $sales;
    public $perPage = 1;
    public $search = '';
    public $tokenData;
    public $messageDelivery;


    public function render()
    {
        $electrixmeters = ElectrixMeter::where('reg_meter_id', '!=', null)->get();
        $wasacmeters = WasacMeter::get();
        $watermeters = ElectrixMeter::where('wasac_meter_id', '!=', null)->get();
        $regmeters = RegMeter::get();
        foreach ($electrixmeters as $item) {
            $electrix_meters[] = [
                'meter_number' => $item->electrix_meter_number
            ];
            $this->electrix_meters = $electrix_meters;
        }

        foreach ($watermeters as $item) {
            $water_meters[] = [
                'meter_number' => $item->electrix_meter_number
            ];
            $this->water_meters = $water_meters;
        }

        foreach ($regmeters as $item) {
            $reg_meters[] = [
                'meter_number' => $item->reg_meter_number
            ];
            $this->reg_meters = $reg_meters;
        }
        if ($this->search_type == 'reg') {
            $this->meters = $this->reg_meters;
        } elseif ($this->search_type == 'electrix') {
            $this->meters = $this->electrix_meters;
        }
        $this->data = $this->getChannels();
        return view('livewire.dashboard.user-dashboard', [
            'electrixmeters' => $this->electrix_meters,
            'meters' => $this->meters,
            'i' => 1,
            'watermeters' => $this->water_meters,
            'data' => $this->data,
        ]);
    }

    protected function rules()
    {
        if ($this->energy) {
            return [
                'amount' => 'required | numeric | min:100',
                'electrix_meter' => 'required',
                'phone' => 'required | numeric | digits:9',
                'payment' => 'required',
            ];
        } elseif ($this->token) {
            return [
                'meter' => 'required',
                'search_type' => 'required'
            ];
        } elseif ($this->water) {
            return [
                'amount' => 'required | numeric | min:100 ',
                'water_meter' => 'required',
                'phone' => 'required | numeric | digits:9',
                'payment' => 'required',
            ];
        }
    }

    public function setEnergy()
    {
        $this->reset();
        if ($this->getApiStatus()['data']['state'] == 'ok') {
            $this->energy = true;
            $this->water = false;
            $this->token = false;
        } else {
            return $this->emit('triggerAlert', 'Our payment system is currently under maintenance!');
        }
    }

    public function setWater()
    {
        if ($this->getApiStatus()['data']['state'] == 'ok') {
            $this->energy = false;
            $this->water = true;
            $this->token = false;
        } else {
            return $this->emit('triggerAlert', 'Our payment system is currently under maintenance!');
        }
    }



    public function setToken()
    {
        $this->reset();
        $this->energy = false;
        $this->water = false;
        $this->token = true;
    }

    public function updated($propertyName)
    {

        if ($propertyName === 'electrix_meter') {
            $electrix_meter = ElectrixMeter::where('electrix_meter_number', $this->electrix_meter)->first();
            $reg_meter = RegMeter::where('id', $electrix_meter->reg_meter_id)->first();
            $vendTrx = $this->validateTrx($reg_meter->reg_meter_number);
            if ($this->electrix_meter != "" && !$this->confirmed && !$this->errorStatus) {
                $this->meterOwner = $vendTrx['customerAccountName'];
                $this->regMeter = $reg_meter->reg_meter_number;
                $this->emit('triggerConfirm', $this->message());
            }
        } elseif ($propertyName == 'water_meter') {
            if ($this->water_meter != "" && !$this->confirmed) {
                $this->emit('triggerConfirm', $this->waterMessage());
            }
        }
        return $this->validateOnly($propertyName);
    }

    public function updatedName($value)
    {
        $this->electrix_meter = $value;
        $this->water_meter = $value;
        $this->confirmed = true;
    }

    public function getApiStatus()
    {
        $url = getenv('FDI_PAYMENT') . "/status";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->get($url);
        return $response->json();
    }

    public function getAuthToken()
    {
        $url = getenv('FDI_PAYMENT') . "/auth";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->post($url, [
            "appId" => getenv('FDI_AP_ID'),
            "secret" => getenv('FDI_AP_SECRET')
        ]);
        return $response->json()['data']['token'];
    }

    public function getUUID()
    {
        $url = "https://www.uuidgenerator.net/api/version4";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->get($url);
        return $response->json()['0'];
    }

    public function getChannels()
    {
        $url = getenv('FDI_PAYMENT') . "/channels";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->getAuthToken()
        ])->get($url);
        return $response->json()['data']['channels'];
    }

    public function validateTrx($meter)
    {
        $url = getenv('FDI_NEW_ENDPOINT') . "/vend/validate";
        try {
            $this->errorStatus = false;
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->vendAuthToken()
            ])->post($url, [
                "verticalId" => "electricity",
                "customerAccountNumber" => $meter
            ]);
            return $response->json()['data'];
        } catch (RequestException $e) {
            $this->errorStatus = true;
            if ($e->response->status() === 422) {
                $errorMessage = $e->response->json('msg');
                // Log or process the error message
                $this->emit('triggerAlert', $errorMessage);
            } else {
                // Handle other exceptions
                $this->emit('triggerAlert', $e->getMessage());
            }
        }
    }

    public function vendAuthToken()
    {
        $url = getenv('FDI_NEW_ENDPOINT') . "/auth";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->post($url, [
            "api_key" => getenv('FDI_API_KEY'),
            "api_secret" => getenv('FDI_API_SECRET')
        ]);
        return $response->json()['data']['accessToken'];
    }

    public function initiatePayment()
    {
        $url = getenv('FDI_PAYMENT') . "/momo/pull";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->getAuthToken()
        ])->post($url, [
            "trxRef" => $this->getUUID(),
            "channelId" => "momo-mtn-rw",
            "accountId" => "92234DCC-FE88-4F2E-941B-E44F06F2B12D",
            "msisdn" =>  '0' . $this->phone,
            "amount" => $this->amount,
            "callback" => "https://830b-2c0f-eb68-61d-4900-6c9e-f41-b486-72f1.ngrok-free.app/api/callback"
        ]);
        $data = $response->json();
        $this->storeTrxData($data);
        $this->emit('triggerSuccess',  '<br> <br> Press <strong>*182*7*1#</strong> to finalize your payment. <br>  <br>
                After making your payment you will receive your energy tokens via SMS <br>');
        return $response->json();
    }

    public function storeTrxData($data)
    {
        $trx = PaymentTransaction::create([
            'trx_status' => $data['status'],
            'trx_data' => json_encode($data, true),
            'trx_ref' => $data['data']['trxRef'],
            'trx_gwref' => $data['data']['gwRef'],
            'trx_state' => $data['data']['state'],
            'reg_meter' => $this->regMeter,
            'electrix_meter' => $this->electrix_meter != null ? $this->electrix_meter : $this->water_meter,
            'amount' => $this->amount,
            'phone' => '0' . $this->phone,
        ]);

        return $trx;
    }

    public function processTransactions()
    {
        $transactions = PaymentTransaction::where('trx_state', 'processing')->whereDate('created_at', Carbon::today())->get();
        if ($transactions) {
            foreach ($transactions as $transaction) {
                // Check if trx_state is not 'processing'
                if ($transaction->trx_state == 'processing') {
                    // Perform your action here
                    if ($this->getTrxInfo($transaction->trx_ref)['data']['trxStatus'] == 'failed') {
                        $updateTrx = PaymentTransaction::where('id', $transaction->id)->update(['trx_state' => 'failed']);
                    } elseif ($this->getTrxInfo($transaction->trx_ref)['data']['trxStatus'] == 'successful') {
                        $trxRef = $this->getUUID();
                        if (ElectrixMeter::where('electrix_meter_number', $transaction->electrix_meter)->first()->reg_meter_id != "") {
                            $this->generateRegToken($transaction->reg_meter, $transaction->electrix_meter, $transaction->amount, '25' . $transaction->phone, $trxRef);
                            $updateTrx = PaymentTransaction::where('id', $transaction->id)->update(['trx_state' => 'successful']);
                        } else {
                            $this->generateWaterToken($transaction->reg_meter, $transaction->electrix_meter, $transaction->amount, '25' . $transaction->phone, $trxRef);
                            $updateTrx = PaymentTransaction::where('id', $transaction->id)->update(['trx_state' => 'successful']);
                        }
                    }
                }
            }
        }
    }


    public function getTrxInfo($trx)
    {
        $url = getenv('FDI_PAYMENT') . "/momo/trx/" . $trx . "/info";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->getAuthToken()
        ])->get($url);

        return $response->json();
    }

    public function message()
    {
        $electrix_meter = ElectrixMeter::where('electrix_meter_number', $this->electrix_meter)->first();
        $reg_meter = RegMeter::where('id', $electrix_meter->reg_meter_id)->first();
        $owner = $reg_meter->client->firstname . " " . $reg_meter->client->lastname;
        $message = "
            <strong>Reg Meter Owner:</strong> $this->meterOwner<br><br>
            <strong>Reg Meter Number:</strong> $this->regMeter<br><br>
            <strong>Electrix Owner:</strong> $owner<br><br>
            <strong>Electrix Meter Number:</strong> $this->electrix_meter<br><br>
            
        ";
        // <strong>Amount:</strong> $this->amount Frw

        return $message;
    }

    public function waterMessage()
    {
        $electrix_meter = ElectrixMeter::where('electrix_meter_number', $this->water_meter)->first();
        $wasac_meter = WasacMeter::where('id', $electrix_meter->wasac_meter_id)->first();
        $owner = $wasac_meter->client->firstname . " " . $wasac_meter->client->lastname;
        $message = "
            <strong>Wasc Meter Owner:</strong> $owner<br><br>
            <strong>Wasac Meter Number:</strong> $wasac_meter->wasac_meter_number<br><br>
            <strong>Electrix Meter Number:</strong> $this->water_meter<br><br>
            
        ";
        // <strong>Amount:</strong> $this->amount Frw

        return $message;
    }

    public function ƒ($meter, $regToken, $electrixToken, $amount, $units, $name)
    {
        $name = $this->trimTo20Characters($name);
        $message = "Meter#: $meter, RegToken: $regToken, ElectrixToken: $electrixToken, Amount: $amount Frw, Units: $units Kwh, Name: $name";
        return $message;
    }

    public function trimTo20Characters($text)
    {
        return substr($text, 0, 20);
    }

    public function save()
    {
        $validatedData = $this->validate();
        $electrix_meter = ElectrixMeter::where('electrix_meter_number', $this->electrix_meter)->first();
        $reg_meter = RegMeter::where('id', $electrix_meter->reg_meter_id)->first();
        $vendTrx = $this->validateTrx($reg_meter->reg_meter_number);
        $this->meterOwner = $vendTrx['customerAccountName'];
        $this->regMeter = $reg_meter->reg_meter_number;
        $this->trxId = $vendTrx['trxId'];
        if ($electrix_meter->meter_status == 'Active') {
            return $this->initiatePayment();
        } else {
            return $this->emit('triggerAlert', 'Your Electrix meter is Inactive, Contact Electrix Support for further assistance!');
        }
    }

    public function checkTransctionReclaim($reg_meter_id, $amount)
    {
        $newAmount = $amount - ($amount * 5 / 100);
        $trx = TransactionReclaim::where('reg_meter_id', $reg_meter_id)->where('amount', $newAmount)->first();
        return $trx;
    }

    public function generateElectrixToken($electrix_meter, $units, $cash)
    {
        $unitNew = $this->calculateAmount($electrix_meter, $units);
        $unit = $this->unitCalibrate($unitNew, $cash);
        $amount = floatval($unit) * 189;
        $meter = $this->validateElectrixMeter($electrix_meter);
        $url = getenv('ELECTRIX_ENDPOINT') . 'VendingMeter';
        if ($meter) {
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
            ])->post($url, [
                'CompanyName' => getenv('COMPANY_NAME'),
                'UserName' => getenv('USERNAME'),
                'PassWord' => getenv('PASSWORD'),
                'MeterID' => strVal($meter),
                'is_vend_by_unit' => "false",
                'Amount' => strVal($amount)
            ]);
            $data = [
                'status' => true,
                'msg' => $meter . ' # Token has been generated successfully!',
                'response' => $response->json()[0],
                'token' => $response->json()[0]['Token'],
            ];
            return $data;
        } else {
            $data = [
                'status' => false,
                'msg' => $meter . ' # meterno not doesn\'t exist',
                'token' => null,
            ];
            return $data;
        }
    }

    public function calculateAmount($meterId, $unit)
    {
        $status = $this->monthlySales($meterId);
        $electrixMeterId = ElectrixMeter::where('electrix_meter_number', $meterId)->first()->id;
        $regMeterId = Sale::where('electrix_meter_id', $electrixMeterId)->first();
        if ($regMeterId) {
            $meterSpeed = RegMeter::where('id', $regMeterId->reg_meter_id)->first()->meter_speed;
            if ($meterSpeed == 'slow' && $status == false) {
                return $units = floatVal($unit) - 1;
            } elseif ($meterSpeed == 'faster' && $status == false) {
                return $units = floatVal($unit) - 1.5;
            } elseif ($meterSpeed == 'fast' && $status == false) {
                return $units = floatVal($unit) - 2;
            } else {
                return $unit;
            }
        } else {
            return $units = floatVal($unit) - 1;
        }
    }

    public function unitCalibrate($units, $amount)
    {
        if ($amount < 1500) {
            return $units - 0.05;
        } elseif ($amount > 1500 && $amount < 3000) {
            return $units - 0.1;
        } elseif ($amount > 3000 && $amount < 5000) {
            return $units - 0.15;
        } elseif ($amount > 5000 && $amount < 8000) {
            return $units - 0.2;
        } elseif ($amount > 8000 && $amount < 10000) {
            return $units - 0.25;
        } elseif ($amount > 10000 && $amount < 20000) {
            return $units - 0.3;
        } elseif ($amount > 20000 && $amount < 30000) {
            return $units - 0.4;
        } else {
            return $units - 0.5;
        }
    }

    public function validateTokenUse($amount, $meterNo)
    {
        $meterId = RegMeter::where('reg_meter_number', $meterNo)->orderBy('id', 'DESC')->first();
        $trx = TransactionReclaim::where('reg_meter_id', $meterId->id)->where('amount', $amount)->where('use_status', false)->first();
        if ($trx) {
            return $trx->token;
        } else {
            return 'null';
        }
    }

    public function balanceRequest()
    {
        $balance =  $this->balanceRequestNewAPI()['data']['wallet_balance'];
        $this->wallet_balance = $balance;
        return response($this->balanceRequestNewAPI(), 200);
    }

    public function mount()
    {
        $this->balanceRequest();
    }

    public function generateRegToken($reg_meter, $electrix_meter, $amountNew, $phone, $trxRef)
    {
        $amount = floatval($amountNew) - floatval($amountNew * 0.06) - 15;
        $amount2 = floatval($amountNew) - floatval($amountNew * 0.05);
        $trx = $this->valitateTrx('electricity', $reg_meter);
        if (gettype($trx) == 'integer') {
            $data = [
                "status_code" => 0,
                "status_msg" => "Meter not found: meter number " . $reg_meter . " does not exist or is not connected.",
                "data" => [
                    "msisdn" => $phone,
                    "amount" => $amount
                ]
            ];
            return response($data, 200);
        } else {
            $requestTrx = $this->validateTokenUse($amount2, $reg_meter);
            if ($requestTrx == 'null') {
                $returnData = $this->executeTrx($trx['data']['trxId'], $reg_meter, $amount, $trx['data']['verticalId'], $trx['data']['deliveryMethods']['0']['id'], $this->removeFirstDigits($phone, 2));
                $this->storeVendTrx('electricity', $trx['data']['trxId']);
                if (is_null($returnData)) {
                    $data = [
                        'status_code' => 0,
                        'status_msg' => 'Transction Barred for 3 minutes',
                        'data' => []
                    ];
                    return response([$data], 200);
                } else {
                    sleep(5);
                    $trx = substr(substr($returnData, 3), 0, -1);
                    $trxData = $this->retrieveTrx($trx);
                    if ($trxData['data']['spVendInfo']['voucher'] != null && $trxData['data']['spVendInfo']['units'] != null) {
                        $meterId = ElectrixMeter::where('electrix_meter_number', $electrix_meter)->first()->id;
                        $this->storeNewApiData('electricity', $returnData, $trxData, $meterId);
                        $data = [
                            "status_code" => 1,
                            "status_msg" => "ELEC VEND METER:" . $trxData['data']['customerAccountNumber'] . " TOKEN:" . $trxData['data']['spVendInfo']['voucher'] . " UNITS: " . $trxData['data']['spVendInfo']['units'] . ", AMOUNT: " . $trxData['data']['spVendInfo']['trxAmount'] . " REF: .0000" . now() . " Name:" . $trxData['data']['customerAccountName'] . " RECEIVER:" . $phone . ". Your balance is:" . $this->wallet_balance,
                            "data" => [
                                "units" => $trxData['data']['spVendInfo']['units'],
                                "token" =>  $trxData['data']['spVendInfo']['voucher'],
                                "meterno" => $trxData['data']['customerAccountNumber'],
                                "regulatory_fees" => $trxData['data']['spVendInfo']['deductions'],
                                "receipt_no" => $trxData['data']['spVendInfo']['receiptNo'],
                                "amount" => $trxData['data']['spVendInfo']['trxAmount'],
                                "vat" => $trxData['data']['spVendInfo']['vatNo'],
                                "customer_name" => $trxData['data']['customerAccountName']
                            ],
                            "tstamp" => now()->format('Y-m-d H:i:s')
                        ];
                        if ($electrix_meter == $reg_meter) {
                            return response($data, 200);
                        } else {
                            if ($data) {
                                $fdiStore = $this->fdiTransactionStore('electricity', json_encode($data), $phone, $electrix_meter);
                                if ($fdiStore) {
                                    $token = $this->generateElectricityTokenNew($electrix_meter, $trxData['data']['spVendInfo']['units']);
                                    if ($token) {
                                        $userId = $this->mobile_user;
                                        $regId = RegMeter::where('reg_meter_number', $reg_meter)->first()->id;
                                        $electrixId = ElectrixMeter::where('electrix_meter_number', $electrix_meter)->first()->id;
                                        $sale = $this->saleStore($userId, $regId, $electrixId, round((floatVal($trxData['data']['spVendInfo']['trxAmount']) + floatVal(15)) / 0.94), round((floatVal($trxData['data']['spVendInfo']['trxAmount']) + floatVal(15)) / 0.94), $this->formatNumberWithHyphens($trxData['data']['spVendInfo']['voucher']), $this->replaceSpacesWithHyphens($token['token']), $trxData['data']['spVendInfo']['units'], true);
                                        if ($sale) {
                                            $tokenSMS = $this->ƒ($electrix_meter, $this->formatNumberWithHyphens($trxData['data']['spVendInfo']['voucher']), $this->replaceSpacesWithHyphens($token['token']), round((floatVal($trxData['data']['spVendInfo']['trxAmount']) + floatVal(15)) / 0.94), $trxData['data']['spVendInfo']['units'], $trxData['data']['customerAccountName']);
                                            $this->triggerSMS($phone, $tokenSMS);
                                            return response($data, 200);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                $reg_meter_id = TransactionReclaim::where('token', $requestTrx)->first()->reg_meter_id;
                $units = TransactionReclaim::where('token', $requestTrx)->first()->units;
                $amount = floatval(TransactionReclaim::where('token', $requestTrx)->first()->amount) / 0.95;
                $reg_meter = RegMeter::where('id', $reg_meter_id)->first()->reg_meter_number;
                $vendTrx = $this->validateTrx($reg_meter);
                $meterOwner = $vendTrx['customerAccountName'];
                $meterId = ElectrixMeter::where('electrix_meter_number', $electrix_meter)->first()->id;
                $data = [
                    "status_code" => 1,
                    "status_msg" => "ELEC VEND METER:" . $reg_meter . " TOKEN:" . $requestTrx . " UNITS: " . $units . ", AMOUNT: " . $amount . " REF: .0000" . now() . " Name:" . $meterOwner . " RECEIVER:" . '250' . $phone . ". Your balance is:" . $this->wallet_balance,
                    "data" => [
                        "units" => $units,
                        "token" =>  $requestTrx,
                        "meterno" => $reg_meter,
                        "regulatory_fees" => [],
                        "receipt_no" => '0000/75495951',
                        "amount" => $amount,
                        "vat" => '103372638',
                        "customer_name" => $meterOwner
                    ],
                    "tstamp" => now()->format('Y-m-d H:i:s')
                ];
                $token = $this->generateElectricityTokenNew($electrix_meter, $units);
                $updateTokenUse = TransactionReclaim::where('token', $requestTrx)->update([
                    'use_status' => true
                ]);
                if ($token) {
                    $userId = $this->mobile_user;
                    $regId = RegMeter::where('reg_meter_number', $reg_meter)->first()->id;
                    $electrixId = ElectrixMeter::where('electrix_meter_number', $electrix_meter)->first()->id;
                    $sale = $this->saleStore($userId, $regId, $electrixId, round((floatVal($amount)) / 0.95), round((floatVal($amount)) / 0.95), $requestTrx, $this->replaceSpacesWithHyphens($token['token']), $units, true);
                    $tokenSMS = $this->ƒ($electrix_meter, $requestTrx, $this->replaceSpacesWithHyphens($token['token']), round((floatVal($amount)) / 0.95), $units, $meterOwner);
                    $this->triggerSMS($phone, $tokenSMS);
                    if ($sale) {
                        return response($data, 200);
                    }
                }
            }
        }
    }

    public function fdiTransactionStore($transaction_type, $transaction_data, $customer_msisdn, $meterNumber)
    {
        $data = FdiTransaction::create([
            'user_id' => MobileUser::where('id', '36')->first()->user_id,
            'customer_msisdn' => $customer_msisdn,
            'transaction_type' => $transaction_type,
            'transaction_data' => $transaction_data,
            'resolve_status' => 0,
            'electrix_meter_number' => $meterNumber,
            'resolve_status' => 1,
            'is_reg_status' => 1,
        ]);
        if ($data) {
            return $data;
        }
    }

    public function generateElectricityTokenNew($meterNumber, $units)
    {
        $unit = $this->calculateAmount($meterNumber, $units);
        $amount = floatval($unit) * 189;
        $meter = $this->validateElectrixMeter($meterNumber);
        $url = getenv('ELECTRIX_ENDPOINT') . 'VendingMeter';
        if ($meter) {
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
            ])->post($url, [
                'CompanyName' => getenv('COMPANY_NAME'),
                'UserName' => getenv('USERNAME'),
                'PassWord' => getenv('PASSWORD'),
                'MeterID' => strVal($meter),
                'is_vend_by_unit' => "false",
                'Amount' => strVal($amount)
            ]);
            $data = [
                'status' => true,
                'msg' => $meter . ' # Token has been generated successfully!',
                'response' => $response->json()[0],
                'token' => $response->json()[0]['Token'],
            ];
            return $data;
        } else {
            $data = [
                'status' => false,
                'msg' => $meter . ' # meterno not doesn\'t exist',
                'token' => null,
            ];
            return $data;
        }
    }

    public function validateElectrixMeter($meterNumber)
    {
        $meter = ElectrixMeter::where('electrix_meter_number', $meterNumber)->with('regmeter')->first();
        if ($meter != '') {
            return $meter->electrix_meter_number;
        } else {
            return null;
        }
    }

    public function saleStore($userId, $regId, $electrixId, $initialCost, $tokenCost, $regToken, $electrixToken, $units, $subscriptionStatus)
    {
        $sale = Sale::create([
            'mobile_user_id' => $userId,
            'reg_meter_id' => $regId,
            'electrix_meter_id' => $electrixId,
            'initial_cost' => ceil(intVal($initialCost)),
            'token_cost' => ceil(intVal($tokenCost)),
            'reg_meter_token' => $regToken,
            'electrix_meter_token' => $electrixToken,
            'units' => $units,
            'subscription_status' => $subscriptionStatus,
        ]);
        return $sale;
    }

    // FDI new API

    public function balanceRequestNewAPI()
    {
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/balance";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url);

        $data = [
            'status_code' => 1,
            'status_msg' => 'Success',
            'data' => [
                'wallet_balance' => $response['total'],
                'commission' => $this->commusionBalance($response),
                'cash' => floatval($response['total']) - floatval($this->commusionBalance($response)),
            ],
            'tstamp' => now()->format('Y-m-d H:i:s')
        ];
        return $data;
    }

    public function generateFdiAuthToken()
    {
        $url = getenv('FDI_NEW_ENDPOINT') . "/auth";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
        ])->post($url, [
            "api_key" => getenv('FDI_API_KEY'),
            "api_secret" => getenv('FDI_API_SECRET')
        ]);
        $token = $response->json()['data']['accessToken'];
        return $response = $token;
    }

    private function commusionBalance($data)
    {
        $iterationCount = 0;
        $balances = 0;
        foreach ($data['data'] as $item) {
            $iterationCount++;
            if ($iterationCount === 1) {
                continue; // Skip the first iteration
            }
            $balance = floatval($item['balance']);
            $balances += $balance;
        }
        return $balances;
    }

    public function queryMeterNewAPI($meterNo)
    {
        try {
            $token = $this->generateFdiAuthToken();
            $url = getenv('FDI_NEW_ENDPOINT') . "/vend/validate";
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token
            ])->post($url, [
                "verticalId" => "electricity",
                "customerAccountNumber" => $meterNo
            ]);
            $data = [
                "status_code" => 1,
                "status_msg" => $response['data']['customerAccountName'],
                "data" => [
                    "vend_min_amount" => $response['data']['vendMin'],
                    "vend_max_amount" => $response['data']['vendMax'],
                    "meterno" => $meterNo,
                    "customer_name" => $response['data']['customerAccountName']
                ],
                "tstamp" => now()->format('Y-m-d H:i:s')
            ];
            return $data;
        } catch (RequestException $exception) {
            $statusCode = $exception->response->status();
            $errorMessage = $exception->response->json()['msg'];
            $data = [
                "status_code" => 0,
                "status_msg" => "Invalid meter number",
                "data" => [
                    "meterno" => $meterNo,
                    "customer_name" => ""
                ],
                "tstamp" => now()->format('Y-m-d H:i:s')
            ];
            return $data;
        }
    }

    private function removeFirstDigits($inputString, $numDigitsToRemove)
    {
        if (is_string($inputString) && strlen($inputString) > $numDigitsToRemove) {
            $resultString = substr($inputString, $numDigitsToRemove);
            return $resultString;
        } else {
            return "Invalid input or not enough characters to remove.";
        }
    }

    public function valitateTrx($trxType, $accountNumber)
    {
        $token = $this->generateFdiAuthToken();
        try {
            $url = getenv('FDI_NEW_ENDPOINT') . "/vend/validate";
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token
            ])->post($url, [
                "verticalId" => $trxType,
                "customerAccountNumber" => $accountNumber
            ]);
            return $response;
        } catch (RequestException $exception) {
            $statusCode = $exception->response->status();
            $errorMessage = $exception->response->json()['msg'];
            $data = [
                'statusCode' => $statusCode,
                'errorMessage' => $errorMessage
            ];
            return $statusCode;
        }
    }

    public function getPreviousTrx($meterno, $verticalId, $amount)
    {
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "electricity/tokens?meterNo=" . $meterno . "&numTokens=1";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url);
        $data = $response->json();
        if (count($data['data']) === 0) {
            return true;
        } else {
            $voucher = $this->formatNumberWithHyphens($data['data'][0]['voucher']);
            $voucherStatus = Sale::where('reg_meter_token', $voucher)->first();
            if ($voucherStatus != NULL) {
                return true;
            } else {
                if ($amount == (intval($data['data'][0]['netAmount']) * -1) && $this->showTimeDifference($data['data'][0]['createdAt']) < 60) {
                    return $data['data'][0]['trxId'];
                } else {
                    return true;
                }
            }
        }
    }

    private function executeTrx($trxId, $customerAccountNumber, $amount, $verticalId, $deliveryMethodId, $deliverTo)
    {
        $status = $this->fetchLastToken($customerAccountNumber, $amount);
        if ($status == true) {
            $token = $this->generateFdiAuthToken();
            $url = getenv('FDI_NEW_ENDPOINT') . "/vend/execute";
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token
            ])->post($url, [
                "trxId" => $trxId,
                "customerAccountNumber" => $customerAccountNumber,
                "amount" => $amount,
                "verticalId" => $verticalId,
                "deliveryMethodId" => $deliveryMethodId,
                "deliverTo" => $deliverTo,
                "callBack" => "https://electrix.rw/electrix-meter-api/"
            ]);
            if (intval($response->getStatusCode()) == 500) {
                return $response;
            } else {
                $response = $response->json();
                return  $response['data']['pollEndpoint'];
            }
        } else {
            return $response = "/v2/trx/" . $trxId . "/status/";
        }
    }

    public function retrieveTrx($trxId)
    {
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . $trxId;
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url);
        if ($response['data']['pdtName'] == "EUCL Prepaid Electricity") {
            if ($response['data']['spVendInfo']['voucher'] == null && $response['data']['spVendInfo']['units'] == null && $response['data']['trxStatusId'] == 'successful') {
                return $this->retrieveTrx($trxId);
            } else if ($response['data']['trxStatusId'] != 'successful') {
                $this->deleteVendTrx('electricity', $trxId);
            } else {
                return $response;
            }
        } else {
            return $response;
        }
    }

    private function storeVendTrx($trx_type, $trx_id)
    {
        $trx = VendTransaction::create([
            'mobile_user_id' => $this->mobile_user,
            'trx_type' => $trx_type,
            'trx_id' => $trx_id,
        ]);
        return $trx;
    }

    private function deleteVendTrx($trx_type, $trx_id)
    {
        $trx = VendTransaction::where('mobile_user_id', auth()->user()->mobileUser->id)->where('trx_type', $trx_type)->where('trx_id', $trx_id)->delete();
        return $trx;
    }


    private function storeNewApiData($trx_type, $trx_id, $trx_data, $meterId)
    {
        $trx = NewApiTransaction::create([
            'mobile_user_id' => $this->mobile_user,
            'electrix_meter_id' => $meterId,
            'trx_type' => $trx_type,
            'trx_id' => $trx_id,
            'trx_data' => $trx_data,
        ]);
        return $trx;
    }

    private function formatNumberWithHyphens($number)
    {
        $numberString = strval($number);
        if (strlen($numberString) !== 20) {
            print_r($numberString);
            throw new InvalidArgumentException("The number must have exactly 20 digits.");
        }
        $formattedNumber = chunk_split($numberString, 4, '-');
        return rtrim($formattedNumber, '-');
    }

    private function replaceSpacesWithHyphens($input)
    {
        return str_replace(' ', '-', $input);
    }

    public function monthlySales($id)
    {
        $meter = ElectrixMeter::where('electrix_meter_number', $id)->with('regmeter')->first();
        $monthlySubscription = Sale::where('subscription_status', true)->where('electrix_meter_id', $meter->id)->whereYear('created_at', Carbon::now()->year)->whereMonth('created_at', Carbon::now()->month)->orderBy('id', 'DESC')->first();
        if ($monthlySubscription != "") {
            return $status = true;
        } else {
            return $status = false;
        }
    }

    // Retrieve Tokens
    public function search()
    {
        $validatedData = $this->validate();
        if ($this->search_type == 'reg') {
            $reg = RegMeter::where('reg_meter_number', $this->meter)->first();
            $searchString = $this->search;
            $this->sales = Sale::with('mobileuser', 'regmeter', 'electrixmeter')->orderBy('id', 'DESC')->where('reg_meter_id', $reg->id)->whereHas('regmeter', function ($query) use ($searchString) {
                $query->where('reg_meter_number', 'like', '%' . $searchString . '%');
            })->orWhereHas('electrixmeter', function ($query) use ($searchString) {
                $query->where('electrix_meter_number', 'like', '%' . $searchString . '%');
            })->orWhereHas('mobileuser', function ($query) use ($searchString) {
                $query->where('firstname', 'like', '%' . $searchString . '%')->orWhere('lastname', 'like', '%' . $searchString . '%')->orWhere('phone', 'like', '%' . $searchString . '%');
            })->limit($this->perPage)->get();
        } elseif ($this->search_type == 'electrix') {
            $electrix = ElectrixMeter::where('electrix_meter_number', $this->meter)->first();
            $searchString = $this->search;
            $this->sales = Sale::with('mobileuser', 'regmeter', 'electrixmeter')->orderBy('id', 'DESC')->where('reg_meter_id', $electrix->id)->whereHas('regmeter', function ($query) use ($searchString) {
                $query->where('reg_meter_number', 'like', '%' . $searchString . '%');
            })->orWhereHas('electrixmeter', function ($query) use ($searchString) {
                $query->where('electrix_meter_number', 'like', '%' . $searchString . '%');
            })->orWhereHas('mobileuser', function ($query) use ($searchString) {
                $query->where('firstname', 'like', '%' . $searchString . '%')->orWhere('lastname', 'like', '%' . $searchString . '%')->orWhere('phone', 'like', '%' . $searchString . '%');
            })->limit($this->perPage)->get();
        }
    }

    // FDI SMS 

    public function generateASMSuthToken()
    {
        $url = getenv('SMS_ENDPOINT') . "/auth";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->post($url, [
            "api_username" => getenv('SMS_API_KEY'),
            "api_password" => getenv('SMS_API_SECRET')
        ]);
        $token = $response->json()['access_token'];
        return $response = $token;
    }

    public function getSMSStatus()
    {
        $url = getenv('SMS_ENDPOINT') . "/status";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->get($url);
        return $response->json()['data']['state'];
    }

    public function getSMSBalance()
    {
        $url = getenv('SMS_ENDPOINT') . "/balance/now";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->generateASMSuthToken()
        ])->get($url);
        return $response->json()['balance']['available'];
    }

    public function ValidateMSISDN($phone)
    {
        $url = getenv('SMS_ENDPOINT') . "/validate/msisdn";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->generateASMSuthToken()
        ])->post($url, [
            "msisdn" => "+" . $phone,
            "countryCode" => "RW"
        ]);
        return $response->json()['valid'];
    }

    public function sendSMS($phone, $message)
    {
        $url = getenv('SMS_ENDPOINT') . "/mt/single";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->generateASMSuthToken()
        ])->post($url, [
            "msisdn" => "+" . $phone,
            "message" => $message,
            "msgRef" => $this->getUUID(),
            "dlr" => "https://electrix.rw/callback",
            "sender_id" => "FDI"
        ]);
        return $response->json()['message'];
    }

    public function triggerSMS($phone, $message)
    {
        $status = $this->getSMSStatus();
        $balance = $this->getSMSBalance();
        $isValid = $this->ValidateMSISDN($phone);
        if ($status == 'ok' && intVal($balance) != 0 && $isValid == true) {
            $this->sendSMS($phone, $message);
        } else {
            return false;
        }
    }

    // Water

    public function saveWater()
    {
        $validatedData = $this->validate();
        $electrix_meter = ElectrixMeter::where('electrix_meter_number', $this->water_meter)->first();
        $this->regMeter = WasacMeter::where('id', $electrix_meter->wasac_meter_id)->first()->wasac_meter_number;
        if ($electrix_meter->meter_status == 'Active') {
            return $this->initiatePayment();
        } else {
            return $this->emit('triggerAlert', 'Your Electrix meter is Inactive, Contact Electrix Support for further assistance!');
        }
    }

    public function generateWaterToken($wasacMeter, $electrixMeter, $cash, $phone, $trxRef)
    {
        $amount = $cash - 15;
        $url = getenv('ELECTRIX_ENDPOINT') . 'VendingMeter';
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
        ])->post($url, [
            'CompanyName' => getenv('COMPANY_NAME'),
            'UserName' => getenv('USERNAME'),
            'PassWord' => getenv('PASSWORD'),
            'MeterID' => $electrixMeter,
            'is_vend_by_unit' => "false",
            'Amount' => strVal($amount)
        ]);
        $data = [
            'status' => true,
            'msg' => $electrixMeter . ' # Token has been generated successfully!',
            'response' => $response->json()[0],
            'token' => $response->json()[0]['Token'],
            'units' => round($response->json()[0]['Total_unit'], 2)
        ];
        $wasacId = WasacMeter::where('wasac_meter_number', $wasacMeter)->first()->id;
        $wasac_meter = WasacMeter::where('wasac_meter_number', $wasacMeter)->first();
        $electrixId = ElectrixMeter::where('wasac_meter_id', $wasacId)->first()->id;
        $electrixToken = $data['token'];
        $units = $data['units'];
        $saleStore = $this->waterSaleStore($this->mobile_user, $wasacId, $electrixId, $cash, $electrixToken, $units, true);
        if ($saleStore) {
            $tokenSMS = $this->waterSMS($electrixMeter, $this->replaceSpacesWithHyphens($data['token']), $cash, $data['units'], $wasac_meter->client->firstname . " " .  $wasac_meter->client->lastname);
            $this->triggerSMS($phone, $tokenSMS);
            return $data;
        }
    }

    public function waterSaleStore($userId, $regId, $electrixId, $tokenCost, $electrixToken, $units, $subscriptionStatus)
    {
        $sale = WaterSale::create([
            'mobile_user_id' => $userId,
            'wasac_meter_id' => $regId,
            'electrix_meter_id' => $electrixId,
            'token_cost' => $tokenCost,
            'water_meter_token' => $electrixToken,
            'units' => $units,
            'commusion_status' => $subscriptionStatus,
        ]);
        return $sale;
    }

    public function waterSMS($meter, $electrixToken, $amount, $units, $name)
    {
        $name = $this->trimTo20Characters($name);
        $electrixToken = $this->replaceSpacesWithHyphens($electrixToken);
        $message = "Meter#: $meter, Water Token: $electrixToken , Amount: $amount Frw, Units: $units m3, Name: $name";
        return $message;
    }

    public function fetchLastToken($meter, $purchaseAmount)
    {
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/electricity/tokens?meterNo=" . $meter . "&numTokens=2";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url);
        $token = $this->formatNumberWithHyphens($response->json()['data'][0]['token']);
        $amount = $response->json()['data'][0]['amount'];
        if (intval($purchaseAmount) == intval($amount)) {
            $tokenStatus = Sale::where('reg_meter_token', $token)->first();
            if ($tokenStatus) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }
}