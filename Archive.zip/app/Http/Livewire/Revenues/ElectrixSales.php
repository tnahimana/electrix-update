<?php

namespace App\Http\Livewire\Revenues;

use App\Models\Sale;
use Livewire\Component;
use Livewire\WithPagination;

class ElectrixSales extends Component
{
    use WithPagination;

    public $perPage = 10;
    public $search = '';
    
    public function render()
    {
        $searchString = $this->search;
        $sales = Sale::with('mobileuser', 'regmeter', 'electrixmeter')->orderBy('id', 'DESC')->whereHas('regmeter', function ($query) use ($searchString){
            $query->where('reg_meter_number', 'like', '%'.$searchString.'%');
        })->orWhereHas('electrixmeter', function ($query) use ($searchString){
            $query->where('electrix_meter_number', 'like', '%'.$searchString.'%');
        })->orWhereHas('mobileuser', function ($query) use ($searchString){
            $query->where('firstname', 'like', '%'.$searchString.'%')->orWhere('lastname', 'like', '%'.$searchString.'%')->orWhere('phone', 'like', '%'.$searchString.'%');
        })->paginate($this->perPage);
        return view('livewire.revenues.electrix-sales',[
            'sales' => $sales,
            'i' => 1
        ]);
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function mount()
    {
        $this->resetPage();
    }

    public function confirmShare($id){
        $sales = Sale::where('id', $id)->update([
            'shared_status' => true,
        ]);
        if($sales){
            $this->emit('success');
            $this->dispatchBrowserEvent('success');
            return back()->with('success', 'Token shared successfully!');
        }else{
            $this->emit('error');
            $this->dispatchBrowserEvent('error');
            return back()->with('success', 'Oops, Something went wrong!');
        }
    }
}