<?php

namespace App\Http\Livewire\Revenues;

use App\Models\Sale;
use Livewire\Component;
use App\Models\SaleRecord;
use Livewire\WithPagination;

class RevenueRecords extends Component
{
    use WithPagination;
    public $record_type;
    public $perPage = 10;
    public $sortBy = 'All';
    public $month;
    public $showMeterRevenues = false;
    public $showCommussionRevenues = false;
    public $showOverallRevenues = false;

    public function render()
    {
        $record = "";
        $recordAll = "";
        $commussion = "";
        $saleRecord = "";
        if($this->sortBy == 'All'){
            if($this->showMeterRevenues){
                $record = SaleRecord::paginate($this->perPage);
                $recordAll = SaleRecord::get();
            }elseif($this->showCommussionRevenues){
                $record = Sale::paginate($this->perPage);
                $recordAll = Sale::get();
            }elseif($this->showOverallRevenues){
                $commussion = Sale::get();
                $saleRecord = SaleRecord::get();
            }
        }elseif($this->sortBy != 'All'){
            if($this->month == ""){
                if($this->showMeterRevenues){
                    $record = SaleRecord::whereYear('created_at', $this->sortBy)->paginate($this->perPage);
                    $recordAll = SaleRecord::whereYear('created_at', $this->sortBy)->get();
                }elseif($this->showCommussionRevenues){
                    $record = Sale::whereYear('created_at', $this->sortBy)->paginate($this->perPage);
                    $recordAll = Sale::whereYear('created_at', $this->sortBy)->get();
                }
            }else{
                if($this->showMeterRevenues){
                    $record = SaleRecord::whereYear('created_at', $this->sortBy)->whereMonth('created_at', $this->month)->paginate($this->perPage);
                    $recordAll = SaleRecord::whereYear('created_at', $this->sortBy)->whereMonth('created_at', $this->month)->get();
                }elseif($this->showCommussionRevenues){
                    $record = Sale::whereYear('created_at', $this->sortBy)->whereMonth('created_at', $this->month)->paginate($this->perPage);
                    $recordAll = Sale::whereYear('created_at', $this->sortBy)->whereMonth('created_at', $this->month)->get();
                }
            }
        }
        return view('livewire.revenues.revenue-records',[
            'meter_sales' => $record,
            'count' => $recordAll,
            'i' => 1,
            'sum' => 0,
            'commussion' => $commussion,
            'saleRecord' => $saleRecord
        ]);
    }

    protected $rules = [
        'record_type' => 'required',
    ];

    public function updated($propertyName){
        return $this->validateOnly($propertyName);
    }

    public function save(){
        $validatedData = $this->validate();
        if($this->record_type == "Meter Revenues"){
            $this->resetPage();
            $this->showMeterRevenues = true;
            $this->showCommussionRevenues = false;
            $this->showOverallRevenues = false;
        }elseif($this->record_type == "Commussion Revenues"){
            $this->resetPage();
            $this->showMeterRevenues = false;
            $this->showCommussionRevenues = true;
            $this->showOverallRevenues = false;
        }elseif($this->record_type == "Revenue Summary"){
            $this->resetPage();
            $this->showMeterRevenues = false;
            $this->showCommussionRevenues = false;
            $this->showOverallRevenues = true;
        }
    }
}