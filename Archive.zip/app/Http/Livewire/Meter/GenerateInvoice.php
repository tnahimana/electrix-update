<?php

namespace App\Http\Livewire\Meter;

use App\Models\Sale;
use Livewire\Component;
use App\Models\RegMeter;
use App\Models\MobileUser;
use App\Models\ElectrixMeter;
use App\Models\FdiTransaction;
use Illuminate\Support\Carbon;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Http;

class GenerateInvoice extends Component
{
    public $mobile_user;
    public $reg_meter;
    public $electrix_meter;
    public $cost;
    public $units;
    public $reg_token;
    public $electrix_token;
    public $commusssion_status = 'Paid';
    public $subscription_status = 1;
    public $mobile_users = [];
    public $reg_meters = [];
    public $electrix_meters = [];
    public $token;
    public $trx_id;
    public $setMeterNumber = false;
    public $meterNumber;
    public $selectType = false;
    public $selection;
    public $invoice_type = 'Internal';
    public $externalDisable  = true;

    public function render()
    {
        $users = MobileUser::get();
        foreach($users as $item){
            $mobile_users[] = [
                'phone' => $item->phone

            ];
            $this->mobile_users = $mobile_users;
        }
        $regmeters = RegMeter::get();
        foreach($regmeters as $item){
            $reg_meters[] = [
                'meter_number' => $item->reg_meter_number

            ];
            $this->reg_meters = $reg_meters;
        }
        $electrixmeters = ElectrixMeter::get();
        foreach($electrixmeters as $item){
            $electrix_meters[] = [
                'meter_number' => $item->electrix_meter_number

            ];
            $this->electrix_meters = $electrix_meters;
        }
        return view('livewire.meter.generate-invoice',[
            'users' => $this->mobile_users,
            'regmeters' => $this->reg_meters,
            'electrixmeters' => $this->electrix_meters,
        ]);
    }

    public function updated($propertyName){
        if($this->selection == 'Internal'){
            $this->reset('setMeterNumber');
            $this->reset('selectType');
        }
        return $this->validateOnly($propertyName);
    }

    protected function rules() {
            return [
            'mobile_user' => 'required',
            'reg_meter' => 'required',
            'electrix_meter' => 'required',
            'cost' => 'required | numeric',
            'units' => 'required',
            'reg_token' => 'required | string',
            'electrix_token' => 'required | string',
            'meterNumber' => [
                'required', 'numeric', 'digits:11',
                Rule::exists('electrix_meters', 'electrix_meter_number')
                ->where('electrix_meter_number', $this->meterNumber),
            ],
        ];
    }

    public function save(){
        $validatedData = $this->validate();
        $this->cost = $this->selection == 'External' ? intVal($this->cost) : intVal($this->cost) / 0.95;
        $mobile_user_id = MobileUser::where('phone', $this->mobile_user)->first();
        $reg_meter_id = RegMeter::where('reg_meter_number', $this->reg_meter)->first();
        $electrix_meter_id = ElectrixMeter::where('electrix_meter_number', $this->electrix_meter)->first();
        if($this->selection == 'Override'){
            $trx = FdiTransaction::where('id', $this->trx_id)->update([
                'resolve_status'=> true,
                'override_status'=> true,
                'override_user' => auth()->user()->id,
            ]);
       }else if($this->selection == 'Normal'){
        $trx = FdiTransaction::where('id', $this->trx_id)->update([
            'resolve_status'=> true,
        ]);
       }else if($this->selection == 'External'){
        $this->invoice_type = 'External';
       }
        $sales = Sale::create([
            'mobile_user_id' => $mobile_user_id->id,
            'reg_meter_id' => $reg_meter_id->id,
            'electrix_meter_id' => $electrix_meter_id->id,
            'units' => $this->units,
            'initial_cost' => intVal($this->cost),
            'token_cost' => intVal($this->cost),
            'reg_meter_token' => $this->cleanRegToken($this->reg_token),
            'electrix_meter_token' => $this->cleanEletrixToken($this->electrix_token),
            'commussion_status' => $this->commusssion_status,
            'subscription_status' => $this->subscription_status,
            'invoice_type' => $this->invoice_type,
        ]);
        if($sales){
            return redirect()->to('/generate-invoice')->with('success', 'Invoice Created Successfully!');
        }else{
            return redirect()->to('/generate-invoice')->with('errror', 'Oops, Something went wrong!');
        }
    }

    public function cleanEletrixToken($token){
      $remove_space = explode(" ",$token);
      $cleaned_token = implode('-', $remove_space);
      return $cleaned_token;
    }

    public function cleanRegToken($token){
        $separator = "-";
        $result = preg_replace('/(\d{4})(?=\d)/', '$1'.$separator, $token);
        return $this->cleanEletrixToken($result);
    }

    public function getTransactionInfo($phone){
       $status = false;
       if($this->selection == 'Override'){
        $status = true;
       }
       $new_phone = '25'. $phone;
       $trx =  FdiTransaction::where('customer_msisdn', $new_phone)
                               ->where('resolve_status', $status)
                               ->where('override_status', false)
                               ->where('transaction_type', 'electrix_electricity')
                               ->latest()->first();
        if(empty($trx)){
            $this->dispatchBrowserEvent('show-error',['error' => 'No pending transaction found!']);
        } else{
            $meter_update = FdiTransaction::where('id', $trx->id)->update([
                'electrix_meter_number' => $this->meterNumber
            ]);
            $this->electrix_meter = $this->meterNumber;
            $this->trx_id = $trx['id'];
            $trx = $trx['transaction_data'];
            if(explode(',', explode(':', $trx)[1])[0] == 0){
                $this->dispatchBrowserEvent('show-error',['error' => 'No pending transaction found!']);
            }elseif(explode(',', explode(':', $trx)[1])[0] == 1){
                $trx = explode('":"', $trx);
                $trx = explode(' ', $trx[1]);
                $this->reg_meter = explode('METER:', $trx[2])[1];
                $this->reg_token = explode('TOKEN:', $trx[3])[1];
                $this->units = explode(',', $trx[5])[0];
                $this->cost = intval($trx[7]);
                if($this->electrix_meter != "null"){
                    $this->electrix_token = $this->generateElectrixToken($this->electrix_meter, $this->units);
                }
            }
        }
    }

    public function setMeterNumber($phone){
       $status = false;
       if($this->selection == 'Override'){
        $status = true;
       }
       $new_phone = '25'. $phone;
       $trx =  FdiTransaction::where('customer_msisdn', $new_phone)
                               ->where('resolve_status', $status)
                               ->where('override_status', false)
                               ->where('transaction_type', 'electrix_electricity')
                               ->latest()->first();
        if(!empty($trx)){
            $meter = $trx->electrix_meter_number;
            if($meter){
               $this->getTransactionInfo($phone);
            }else{
                $setMeter = FdiTransaction::where('id', $trx->id)->update([
                    'eletrix_meter_number' => $this->meterNumber,
                ]);
                if($setMeter){
                    $this->getTransactionInfo($phone);
                }
            }
        }else{
            $this->setMeterNumber = false;
            $this->dispatchBrowserEvent('show-error',['error' => 'No pending transaction found!']);
        }
    }

    public function addMeterNumber(){
        if($this->selection == 'External'){
            $this->validateOnly('mobile_user');
            $this->validateOnly('cost');
            $this->validateOnly('units');
            $this->validateOnly('reg_token');
            $this->validateOnly('meterNumber');
            $this->reg_meter = ElectrixMeter::where('electrix_meter_number', $this->meterNumber)->first()->regmeter->reg_meter_number;
            $this->electrix_meter = $this->meterNumber;
            $this->electrix_token = $this->generateElectrixToken($this->meterNumber, $this->units);
            $this->externalDisable = false;
            if(strlen($this->electrix_token) == 24){
                $this->save();
            }else{
                 $this->externalDisable = false;   
            }
        }else{
            $this->validateOnly('meterNumber');
            $this->setMeterNumber = true;
            $this-> setMeterNumber($this->mobile_user);
        }
    }

    public function generateElectrixToken($meter_number,$units)
    {
        $unit = $this->calculateAmount($meter_number, $units);
        $amount = intval($unit * 189);
        try {
            $response = Http::post('http://www.newapi.stronpower.com/api/VendingMeter',[
                "CompanyName" => "Genius-Solutions",
                "UserName" =>"Admin84",
                "PassWord" => "123456",
                "MeterID"=> $meter_number,
                "is_vend_by_unit"=> "false",
                "Amount"=> $amount
            ]);
            $result = $response->json();
            $this->token = $result[0]['Token'];

        } catch (\Throwable $th) {
            return $this->token = 'Error';
        }
        return $this->token;
    }

    public function monthlySales($id)
    {
        $meter = ElectrixMeter::where('electrix_meter_number', $id)->with('regmeter')->first();
        $monthlySubscription = Sale::where('subscription_status', true)->where('electrix_meter_id', $meter->id)->whereYear('created_at', Carbon::now()->year)->whereMonth('created_at', Carbon::now()->month)->orderBy('id', 'DESC')->first();
        if ($monthlySubscription != "") {
            return $status = true;
        } else {
            return $status = false;
        }
    }

    public function calculateAmount($meterId, $unit)
    {
        $status = $this->monthlySales($meterId);
        $electrixMeterId = ElectrixMeter::where('electrix_meter_number', $meterId)->first()->id;
        $regMeterId = Sale::where('electrix_meter_id', $electrixMeterId)->first()->reg_meter_id;
        $meterSpeed = RegMeter::where('id', $regMeterId)->first()->meter_speed;
        if ($meterSpeed == 'slow' && $status == false) {
            return $units = floatVal($unit) - 1;
        } elseif ($meterSpeed == 'faster' && $status == false) {
            return $units = floatVal($unit) - 1.5;
        } elseif ($meterSpeed == 'fast' && $status == false) {
            return $units = floatVal($unit) - 2;
        } else {
            return $unit;
        }
    }
}