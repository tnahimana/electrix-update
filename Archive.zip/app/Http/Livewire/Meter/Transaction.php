<?php

namespace App\Http\Livewire\Meter;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\PaymentTransaction;

class Transaction extends Component
{
    use WithPagination;

    public $perPage = 10;
    public $search = '';
    
    public function render()
    {
        $transactions = PaymentTransaction::orderBy('id', 'DESC')->paginate($this->perPage);
        return view('livewire.meter.transaction',[
            'transactions' => $transactions,
            'i' => 1
        ]);
    }
}