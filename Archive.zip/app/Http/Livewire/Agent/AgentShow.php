<?php

namespace App\Http\Livewire\Agent;

use App\Models\Image;
use App\Models\Agents;
use Livewire\Component;
use App\Models\MobileUser;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Storage;

class AgentShow extends Component
{
    use WithFileUploads;
    
    public $agent;
    public $image;
    public $personalInfo = true;
    public $contactInfo = false;
    public $addressInfo = false;
    public $showImage = false;
    public $mobile_role;

    public function render()
    {
        return view('livewire.agent.agent-show');
    }

    public function mount($id)
    {
        $this->agent = Agents::find($id);
        $this->mobile_role = MobileUser::where('user_id', $this->agent->user_id)->first();
    }

    public function personalInfo(){
        $this->personalInfo = true;
        $this->contactInfo = false;
        $this->addressInfo = false;
    }

    public function contactInfo(){
        $this->personalInfo = false;
        $this->contactInfo = true;
        $this->addressInfo = false;
    }

    public function addressInfo(){
        $this->personalInfo = false;
        $this->contactInfo = false;
        $this->addressInfo = true;
    }

    public function addImage(){
        $this->showImage = true;
    }

    protected $rules = [
        'image' => 'required|image|max:1024', // 1MB Max
    ];

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function upload($id){

        $validatedData = $this->validate();
        $this->previous_image($id);
        $image = $this->saveImage($this->image, 'images');
        if($this->previous_image($id) == false){
            $saveImage = Image::create([
                'img_url' => $image
            ]);
        }else{
            $saveImage = Image::where('id',$this->previous_image($id))->update([
                'img_url' => $image
            ]);
        }
        if($saveImage){
            $image_id = Image::where('img_url',$image)->latest()->first();
        }
        Agents::find($id)->update([
            'image_id' => $image_id->id
        ]);
        $this->shiftPage();
        $this->resetImage();
        return $this->mount($id);
    }

    public function resetImage(){
        $this->showImage = false;
        $this->resetValidation();
        $this->image = null;
    }

    public function previous_image($id){
        $agent = Agents::find($id);
        if($agent->image_id != null){
            $image = Image::find($agent->image_id);
            $image_path = $image->img_url;
            if(Storage::exists($image_path)){
                Storage::delete($image_path);
            }
            return $image->id;
        }else{
            return false;
        }
    }

    public function shiftPage(){
        if($this->personalInfo){
            return $this->contactInfo();
        }elseif($this->contactInfo){
            return $this->personalInfo();
        }elseif($this->addressInfo){
            return $this->personalInfo();
        }
    }

    public function activate($id){
        Agents::where('id',$id)->update([
            'account_status' => 'Active',
        ]);
        session()->flash('success', 'Account Activated!');
        return $this->mount($id);
    }

    public function suspend($id){
        Agents::where('id',$id)->update([
            'account_status' => 'Inactive',
        ]);
        session()->flash('success', 'Account Suspended!');
        return $this->mount($id);
    }

    public function allowApp(){
        MobileUser::where('user_id', $this->agent->user_id)->update([
            'extra_role' => 'allowed'
        ]);
        $route = '/agents/' . $this->agent->id;
        return redirect()->to($route)->with('success', 'User Allowed for Mobile App');
    }

    public function blockApp(){
        MobileUser::where('user_id', $this->agent->user_id)->update([
            'extra_role' => 'blocked'
        ]);
        $route = '/agents/' . $this->agent->id;
        return redirect()->to($route)->with('success', 'User Allowed for Mobile App');
    }
}
