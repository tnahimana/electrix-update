<?php

namespace App\Http\Livewire\Admin;

use App\Models\Cell;
use App\Models\Admins;
use App\Models\Sector;
use App\Models\Address;
use App\Models\Village;
use Livewire\Component;
use App\Models\District;
use App\Models\Document;
use App\Models\Province;

class AdminUpdate extends Component
{
    public $firstname;
    public $middlename;
    public $lastname;
    public $phone;
    public $province;
    public $prov;
    public $district;
    public $dist;
    public $sector;
    public $sect;
    public $cell;
    public $cel;
    public $village;
    public $vil;
    public $ids;

    public function render()
    {
        return view('livewire.admin.admin-update',[
            'document' => Document::get(),
            'provinces' => Province::get(),
            'districts' => District::where('province_id', $this->province)->get(),
            'sectors' => Sector::where('district_id', $this->district)->get(),
            'cells' => Cell::where('sector_id', $this->sector)->get(),
            'villages' => Village::where('cell_id', $this->cell)->get(),
        ]);
    }

    public function mount($id){
        $admin = Admins::find($id);
        $this->ids = $id;
        $this->firstname = $admin->firstname;
        $this->middlename = $admin->middlename;
        $this->lastname = $admin->lastname;
        $this->phone = $admin->phone;
        $this->prov = $admin->address->province->province;
        $this->dist = $admin->address->district->district;
        $this->sect = $admin->address->sector->sector;
        $this->cel = $admin->address->cell->cell;
        $this->vil = $admin->address->village->village;
    }

    protected $rules = [
        'province' => 'required',
        'district' => 'required',
        'sector' => 'required',
        'cell' => 'required',
        'village' => 'required',
    ];

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function save($id){
        if(auth()->user()->role->name == 'super_admin'){
            $validatedData = $this->validate();
            $this->phone($this->phone, $id);
            $this->addressStore($id);
            $this->dispatchBrowserEvent('hide-form',['success' => 'Admin Info updated successfully!']);
            return redirect()->to('/admins/'. $id)->with('success', 'Admin Info updated successfully!');
        }else{
            return redirect()->to('/dashboard')->with('error', 'Unauthorized Action!');
        }
    }

    public function addressStore($id){
        $admin = Admins::find($id);
        Address::where('id', $agent->address_id)->update([
            'province_id' => $this->province,
            'district_id' => $this->district,
            'sector_id' => $this->sector,
            'cell_id' => $this->cell,
            'village_id' => $this->village,
        ]);
        return true;
    }

    public function phone($phone,$id){
        $admin = Admins::where('phone', $phone)->first();
        if($admin != null){
            $validatedData = $this->validate([
                'phone' => 'required | numeric | regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
            ]);
            return $validatedData;
        }else{
            $validatedData = $this->validate([
                'phone' => 'required | numeric | regex:/^([0-9\s\-\+\(\)]*)$/|min:10 | unique:admins',
            ]);
            Admins::find($id)->update([
                'phone' => $this->phone, 
            ]);
            return $validatedData;
        }
    }
}
