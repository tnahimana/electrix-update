<?php

namespace App\Http\Livewire\Contact;

use App\Models\Message;
use Livewire\Component;

class Contact extends Component
{
    public $name;
    public $email;
    public $subject;
    public $message;
    public $feedback;

    public function render()
    {
        return view('livewire.contact.contact');
    }

    public function mount(){
        return $this->feedback;
    }

    protected $rules = [
        'name' => 'required | string',
        'email' => 'required | email',
        'subject' => 'required | string',
        'message' => 'required | string',
    ];

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function save(){
       $message =  Message::create([
            'name' => $this->name,
            'email' => $this->email,
            'subject' => $this->subject,
            'message' => $this->message,
        ]);
        if($message){
            $this->name = "";
            $this->email = "";
            $this->subject = "";
            $this->message = "";
            $this->feedback = "Message sent successfuly!";
        }
    }

}
