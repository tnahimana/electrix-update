<?php

namespace App\Http\Livewire\Schedule;

use Livewire\Component;
use App\Models\Schedule;
use Livewire\WithPagination;

class ScheduleIndex extends Component
{
    use WithPagination;

    public $perPage = 10;
    public $search = '';
    
    public function render()
    {
        return view('livewire.schedule.schedule-index',[
            'schedules' => Schedule::with('mobileUser', 'electrixmeter','electrixmeter.regmeter')->orderBy('id', 'DESC')->paginate($this->perPage),
            'i' => 1
        ]);
    }

    public function deleteSchedule($id){
        dd($id);
    }
}