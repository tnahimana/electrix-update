<?php

namespace App\Http\Livewire\Shortcode;

use App\Models\Update;
use Livewire\Component;

class ShortcodeUpdate extends Component
{
    public $value;
    public $name;
    public $status;
    public $ids;

    public function render()
    {
        return view('livewire.shortcode.shortcode-update');
    }

    public function mount($update){
        $this->name = $update->name;
        $this->status = $update->server_status;
        $this->value = $update->value;
        $this->ids = $update->id;
    }

    protected $rules = [
        'value' => 'required | string | min:3',
        'status' => 'required'
    ];

    public function updated($propertyName){
        return $this->validateOnly($propertyName);
    }

    public function save(){
        $validatedData = $this->validate();
        $shortcode = Update::where('id', $this->ids)->update([
            'value' => $this->value,
            'server_status' => $this->status,
        ]);
        if($shortcode){
            $this->reset();
            return redirect()->to('/updates')->with('success', 'App Release Version Updated Successfuly!');
        }
    }
}
