<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EnergyController extends Controller
{
    public function dashboard(){
        return view('energy.dashboard');
    }
}