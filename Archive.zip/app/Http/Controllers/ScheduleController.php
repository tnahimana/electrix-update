<?php

namespace App\Http\Controllers;

use App\Models\Schedule;
use Illuminate\Http\Request;

class ScheduleController extends Controller
{
    public function scheduleSale(){
        return view('schedule.create');
    }

    public function scheduledSales(){
        return view('schedule.index');
    }

    public function deleteSchedule($id){
        $schdeule = Schedule::where('uuid', $id)->first();
        $schdeule = $schdeule->delete();
        if($schdeule){
            return redirect()->to('/scheduled-sales')->with('success', 'Scheduled sale deleted successfully!');
        }else{
          return redirect()->to('/scheduled-sales')->with('error', 'Oops, something went wrong!');  
        }
    }
}