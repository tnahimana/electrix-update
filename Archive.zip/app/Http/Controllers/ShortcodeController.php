<?php

namespace App\Http\Controllers;

use App\Models\Update;
use Illuminate\Http\Request;

class ShortcodeController extends Controller
{
    public function __construct()
    {
        $this->middleware(['Admin']);
    }

    public function index(){
        return view('shortcode.index');
    }

    public function create(){
        return view('shortcode.create');
    }

    public function edit($id){
        return view('shortcode.show',[
            'update' => Update::find($id),
        ]);
    }

    public function apps(){
        return view('file.index');
    }
}
