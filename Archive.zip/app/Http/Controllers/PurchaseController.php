<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Livewire\Dashboard\UserDashboard;

class PurchaseController extends Controller
{
    public function dashboard(){
        return view('dashboard.user-dashboard');
    }

}