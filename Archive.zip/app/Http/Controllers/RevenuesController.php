<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RevenuesController extends Controller
{
    public function __construct()
    {
        $this->middleware(['Admin']);
    }

     public function registerSale(){
        return view('revenues.sale-register');
    }

    public function revenueRecords(){
        return view('revenues.revenue-records');
    }

    public function ElectrixSales(){
        return view('revenues.electrix-sales');
    }
}