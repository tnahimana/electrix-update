<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LogoutController extends Controller
{
    public function __construct()
    {
        $this->middleware(['Moderator']);
    }
    
    public function index()
    {
        auth()->user()->tokens()->delete();
        auth()->logout();

        return redirect('/');
    }
}