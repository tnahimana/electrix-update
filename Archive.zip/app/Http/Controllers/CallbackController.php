<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class CallbackController extends Controller
{
    public function handleCallback(Request $request)
    {
        // Log the entire request for debugging purposes (optional)
        Log::info('Callback received:', $request->all());

        // Validate the incoming data
        $validated = $request->validate([
            'status' => 'required|string',
            'data' => 'required|array',
        ]);

        // Extract the status and data
        $status = $validated['status'];
        $data = $validated['data'];

        switch ($status) {
            case 'success':
                if (isset($data['state']) && $data['state'] === 'successful') {
                    // Handle successful transaction
                    return response()->json(['message' => 'Transaction successful.'], 200);
                } elseif (isset($data['state']) && $data['state'] === 'processing') {
                    // Handle transaction processing
                    return response()->json(['message' => 'Transaction is processing.'], 202);
                }
                break;

            case 'fail':
                // Handle failed transaction
                return response()->json([
                    'message' => $data['message'] ?? 'Transaction failed.',
                    'details' => $data
                ], 400);

            case 'error':
                // Handle gateway-side errors
                return response()->json([
                    'message' => $data['message'] ?? 'An error occurred.',
                    'details' => $data
                ], 500);

            default:
                // Handle unknown statuses
                return response()->json(['message' => 'Unknown status received.'], 422);
        }
    }
}