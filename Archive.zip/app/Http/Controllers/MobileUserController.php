<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use App\Models\MobileUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class MobileUserController extends Controller
{
    public function register(Request $request){
        $attrs = $request->validate([
            'firstname' => 'required|string',
            'middlename' => 'string',
            'lastname' => 'required|string',
            'phone'=> 'required | numeric | regex:/^([0-9\s\-\+\(\)]*)$/|min:10 | unique:mobile_users',
            'email' => 'required|email|unique:mobile_users',
            'password' => 'required|min:8',
            'password_confirmation' => 'required|min:8|same:password',
        ]);
        $role = Role::where('name', 'mobile_client')->first();
        $user = User::create([
            'email' => $attrs['email'],
            'username' => $attrs['email'],
            'role_id' => $role->id,
            'password' => Hash::make($attrs['password']),
        ]);
        $mobile = MobileUser::create([
            'user_id' => $user->id,
            'firstname' => $attrs['firstname'],
            'middlename' => $request->input('middlename'),
            'lastname' => $attrs['lastname'],
            'email' => $attrs['email'],
            'phone' => $attrs['phone'],
            'password' => Hash::make($attrs['password']),
        ]);

        return response([
            'user' => $user,
            'token' => $user->createToken('secret')->plainTextToken,
        ], 200);
    }

    public function login(Request $request){
        $attrs = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8',
        ]);

        if(!Auth::attempt($attrs)){
            return response([
                'message' => 'Invalid login credentials.'
            ], 403);
        }elseif(Auth::attempt($attrs)){
            $role_client = auth()->user()->role->name == 'client' ? 'client' : '';
            $role_agent = auth()->user()->role->name == 'agent' ? 'agent' : '';
            $role = Role::where('name', 'mobile_client')->orWhere('name', $role_agent != ''? $role_agent : $role_client )->first();
            $auth = auth()->user();
            if($auth->role_id == $role->id){
            return response([
                'user' => auth()->user(),
                'token' => auth()->user()->createToken('secret')->plainTextToken,
            ], 200);
            }else{
                auth()->user()->tokens()->delete();
                return response([
                    'message' => 'Invalid login credentials.'
                ], 403);
            }
        }
    }

    public function logout(){
        auth()->user()->tokens()->delete();
        return response([
            'message' => 'Logout Successfully!'
        ], 200);
    }
    
    public function user(){
        $user = User::where('id',auth()->user()->id)->with('mobileUser')->first();

        return response([
          'user' => [  
                'id' => $user->id,
                'username'=> $user->username,
                'email'=> $user->email,
                'firstname'=> $user->mobileUser->firstname,
                'lastname'=> $user->mobileUser->lastname,
                'phone'=> $user->mobileUser->phone,
            ]
        ],200);

    }

    public function profile(){
        $user = User::where('id', auth()->user()->id)->with('mobileUser')->first();
        return response([
            'profile' => [
                'firstname' => $user->mobileUser->firstname,
                'lastname' => $user->mobileUser->lastname,
                'email' => $user->mobileUser->email,
                'phone' => $user->mobileUser->phone,
            ]
        ],200);
    }

    public function saleUpdate($id){
        $sale = Sale::where('electrix_meter_id', $id)->orderBy('id', DESC)->update([
            'commussion_status' => 'Paid',
        ]);

        return response([
            'sale' => $sale,
        ],200);
    }

}