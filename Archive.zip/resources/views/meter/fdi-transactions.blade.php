@extends('../layout/' . $layout)

@section('title')
    FDI Transactions | Electrix Vending
@endsection

@section('active-meters')
    side-menu--active
@endsection

@section('navigation')
    FDI Transactions
@endsection

@section('navigation-url')
    fdi-transactions
@endsection

@section('subcontent')
    @livewire('meter.fdi-transactions')
@endsection