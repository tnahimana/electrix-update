@extends('../layout/' . $layout)

@section('title')
    Transactions | Electrix Vending
@endsection

@section('active-meters')
    side-menu--active
@endsection

@section('navigation')
    Transactions
@endsection

@section('navigation-url')
    transactions
@endsection

@section('subcontent')
    @livewire('meter.transaction')
@endsection