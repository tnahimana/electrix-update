@extends('../layout/' . $layout)

@section('title')
    Release Update | Electrix Vending
@endsection

@section('active-shortcode')
    side-menu--active
@endsection

@section('navigation')
    Release Update
@endsection

@section('navigation-url')
    create
@endsection

@section('subcontent')
    @livewire('shortcode.shortcode-create')
@endsection