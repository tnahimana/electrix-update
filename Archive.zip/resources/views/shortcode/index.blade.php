@extends('../layout/' . $layout)

@section('title')
   App Release Versions | Electrix Vending
@endsection

@section('active-shortcode')
    side-menu--active
@endsection

@section('navigation')
App Release Versions
@endsection

@section('navigation-url')
    updates
@endsection

@section('subcontent')
    @livewire('shortcode.shortcode-index')
@endsection