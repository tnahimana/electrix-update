@extends('../layout/' . $layout)

@section('title')
    Admins | Electrix Vending
@endsection

@section('active-admin')
    side-menu--active
@endsection

@section('navigation')
    Admins
@endsection

@section('navigation-url')
    admins
@endsection

@section('subcontent')
    @livewire('admin.admin-index')
@endsection