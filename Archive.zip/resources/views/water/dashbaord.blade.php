@extends('../layout/' . $layout)

@section('title')
    Dashbaord | Electrix Vending
@endsection

@section('dashbaord')
    side-menu--active
@endsection

@section('navigation')
   Water Dashbaord
@endsection

@section('navigation-url')
    water-dashboard
@endsection

@section('subcontent')
    @livewire('dashboard.water-dashboard')
@endsection