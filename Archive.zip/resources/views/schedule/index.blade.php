@extends('../layout/' . $layout)

@section('title')
    Scheduled Sales | Electrix Vending
@endsection

@section('active-schedule')
    side-menu--active
@endsection

@section('navigation')
    Scheduled Sales
@endsection

@section('navigation-url')
    scheduled-sales
@endsection

@section('subcontent')
    @livewire('schedule.schedule-index')
@endsection