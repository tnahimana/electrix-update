@extends('../layout/' . $layout)

@section('title')
    Register Agent | Electrix Vending
@endsection

@section('active-agent')
    side-menu--active
@endsection

@section('navigation')
    Register Agent
@endsection

@section('navigation-url')
    create
@endsection

@section('subcontent')
    @livewire('agent.agent-create')
@endsection