@extends('../layout/' . $layout)

@section('title')
    Password Reset | Electrix Vending
@endsection

@section('active-users')
    side-menu--active
@endsection

@section('navigation')
    Meter Actions
@endsection

@section('navigation-url')
    password-reset
@endsection

@section('subcontent')
    @livewire('password.password')
@endsection