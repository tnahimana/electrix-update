<div>
    @if(session('error'))
        <div class="btn alert-danger col-12 mb-1">
        {{ session('error') }}
        </div>
    @endif
    <form wire:submit.prevent="login">
        <div class="form-group mb-50">
            <label class="text-bold-600" for="exampleInputEmail1">Email address</label>
            <input wire:model="email" type="email" class="form-control" id="exampleInputEmail1" placeholder="Email address"></div>
        <div class="form-group">
            <label class="text-bold-600" for="exampleInputPassword1">Password</label>
            <input wire:model="password" type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
        </div>
        <div class="form-group d-flex flex-md-row flex-column justify-content-between align-items-center">
            <div class="text-left">
                <div class="checkbox checkbox-sm">
                    <input wire:model="remember" type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="checkboxsmall" for="exampleCheck1"><small>Keep me logged
                            in</small></label>
                </div>
            </div>
            <div class="text-right"><a href="#" class="card-link"><small>Forgot Password?</small></a></div>
        </div>
        <button type="submit" class="btn btn-primary glow w-100 position-relative">Login</button>
    </form>
</div>