<div class="content" id="centered">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="save">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6"> Release Update</h2>
                    </div>

                    <div class="intro-y box mt-5">
                    
                        <div id="inline-form" class="p-5">

                            <div class="preview mr-5 ml-5">
                                <div class="flex flex-wrap -mx-3 mb-2">
                                    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Name</label>
                                            <input id="input-state-1" wire:model="name" type="text" class="form-control @error('name') border-theme-6 @elseif($name != "") border-theme-9 @enderror" value="{{ $name }}" disabled>
                                            @error('name')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-2" class="form-label">Value</label>
                                            <input id="input-state-2" wire:model="value" type="text" class="form-control @error('value') border-theme-6 @elseif($value != "") border-theme-9 @enderror" placeholder="release version...">
                                            @error('value')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>

                            </div>

                            <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end">         
                                    <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 mt-5 mr-2 mb-2"> Submit <div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
            </form>
        </div>

    </div>    
</div>