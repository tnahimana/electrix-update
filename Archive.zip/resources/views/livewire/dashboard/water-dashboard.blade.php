<div class="grid grid-cols-12 gap-6">
    <div class="col-span-12 2xl:col-span-9">
        <div class="grid grid-cols-12 gap-6">
            <!-- BEGIN: General Report -->
            <div class="col-span-12 mt-8">
                <div class="intro-y flex items-center h-10">
                    <h2 class="text-lg font-medium truncate mr-5">
                        Dashboard
                    </h2>
                    <a href="" class="ml-auto flex items-center text-theme-1 dark:text-theme-10">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h5 mr-2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
                        </svg>

                        Reload Data </a>
                </div>
                @if($sales != null)
                    {{-- <span wire:loading.remove> --}}
                        @include('sales.search-sales-model')
                    {{-- </span> --}}
                @endif
                @if($showInfo)
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <div class="col-span-12 sm:col-span-6 xl:col-span-4 intro-y">
                            <div class="report-box zoom-in">
                                <div class="box p-5">
                                    <div class="flex">
                                        <object data="{{ asset('assets/svg/wasac.svg') }}" class="report-box__icon text-theme-10 w-20 h-20"></object>
                                        <div class="ml-auto">
                                            <div class="text-3xl font-medium leading-8">
                                                @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                                                    {{ $wasac_meters_admin }}
                                                @elseif(auth()->user()->role->name == 'agent')
                                                    {{ $wasac_meter_agent }}
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-3xl font-medium leading-8 mt-6">

                                    </div>
                                    <div class="text-base text-gray-600 mt-1">Wasac Meters</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-span-12 sm:col-span-6 xl:col-span-4 intro-y">
                            <div class="report-box zoom-in">
                                <div class="box p-5">
                                    <div class="flex">
                                        <object data="{{ asset('assets/svg/electrix.svg') }}" class="report-box__icon text-theme-10 w-20 h-20"></object>
                                        <div class="ml-auto">
                                            <div class="text-3xl font-medium leading-8">
                                                @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                                                    {{ $electrix_meters_admin }}
                                                @elseif(auth()->user()->role->name == 'agent')
                                                    {{ $electrix_meters_agent }}
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-3xl font-medium leading-8 mt-6">

                                    </div>
                                    <div class="text-base text-gray-600 mt-1"> Electrix  Meters</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-span-12 sm:col-span-6 xl:col-span-4 intro-y" wire:click="getInfo">
                            <div class="report-box zoom-in">
                                <div class="box p-5">
                                    <div class="flex">
                                        <object data="{{ asset('assets/svg/electrix_wasac.svg') }}" class="report-box__icon text-theme-10 w-20 h-20"></object>
                                        <div class="ml-auto">
                                            <div class="text-3xl font-medium leading-8">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 report-box__icon text-theme-10">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-3xl font-medium leading-8 mt-6">

                                    </div>
                                    <div class="text-base text-gray-600 mt-1">Retrieve Meter Info</div>
                                </div>
                            </div>
                        </div>
                    </div>
                @else
                    @if($showDashboard)
                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="col-span-12 sm:col-span-6 xl:col-span-4 intro-y">
                                <div class="report-box zoom-in">
                                    <div class="box p-5">
                                        <div class="flex">
                                            <object data="{{ asset('assets/svg/wasac.svg') }}" class="report-box__icon text-theme-10"></object>
                                            <div class="ml-auto">
                                                <div class="text-md font-medium leading-8">
                                                Meter N<sup>o</sup> {{ $selected_meter->wasacmeter->wasac_meter_number }}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-3xl font-medium leading-8 mt-6">

                                        </div>
                                        <div class="text-base text-gray-600 mt-1">Wasac Meter</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-span-12 sm:col-span-6 xl:col-span-4 intro-y">
                                <div class="report-box zoom-in">
                                    <div class="box p-5">
                                        <div class="flex">
                                            <object data="{{ asset('assets/svg/electrix.svg') }}" class="report-box__icon text-theme-10"></object>
                                            <div class="ml-auto">
                                                <div class="text-md font-medium leading-8">
                                                Meter N<sup>o</sup> {{ $search_meter }}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-3xl font-medium leading-8 mt-6">

                                        </div>
                                        <div class="text-base text-gray-600 mt-1"> Sales History</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-span-12 sm:col-span-6 xl:col-span-4 intro-y" wire:click="getInfo">
                                <div class="report-box zoom-in">
                                    <div class="box p-5">
                                        <div class="flex">
                                            <object data="{{ asset('assets/svg/electrix_wasac.svg') }}" class="report-box__icon text-theme-10 w-20 h-20"></object>
                                            <div class="ml-auto">
                                                <div class="text-md font-medium leading-8" style="text-transform: capitalize">
                                                    @if($meterrecords->management_type == 'other')
                                                    Managed By Electrix Ltd
                                                    @else
                                                    Managed By Client
                                                    @endif

                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-3xl font-medium leading-8 mt-6">

                                        </div>
                                        <div class="text-base text-gray-600 mt-1">Management Type</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                    <div class="content">
                        <x-loading />
                        <div class="grid grid-cols-12 gap-6 mt-5" style="z-index: 99999; position:relative">
                            <div class="intro-y col-span-12 place-items-center lg:col-span-12">
                                <form action="POST" wire:submit.prevent="search">
                                    <div class="intro-y box mt-5" style="border-top: 3px solid blue">
                                        <div class="intro-y box mt-5">

                                            <div id="inline-form" class="p-0">

                                                <div class="preview pl-5">

                                                    <div class="flex flex-wrap -mx-3 mb-2">

                                                        <div class="w-full md:w-10/12 px-3">
                                                            <x-simple-select
                                                                name="search_meter"
                                                                id="search_meter"
                                                                :options="$meters"
                                                                value-field='meter_number'
                                                                text-field='meter_number'
                                                                placeholder="Search meter"
                                                                search-input-placeholder="Search meter"
                                                                :searchable="true"
                                                                id="input-state-3"
                                                                wire:model="search_meter"
                                                                class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                                            />
                                                            @error('search_meter')
                                                                <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                                            @enderror

                                                        </div>

                                                         <div class="w-full md:w-2/12 px-3 ">
                                                            <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end">
                                                                    <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-6 pr-6 -mt-4 h-12"> Search <div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                                                            </div>
                                                        </div>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </form>
                            </div>

                        </div>
                        @if($this->showDetails)
                            <section>
                                <div class="grid grid-cols-12 gap-6 mt-0">
                                    <!-- BEGIN: Data List -->
                                    <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                                        <table class="table table-report -mt-2">
                                            <thead>
                                                <tr>
                                                    <th class="whitespace-nowrap">S/N</th>
                                                    <th class="whitespace-nowrap" colspan="2">WASAC METER INFO</th>
                                                    <th class="whitespace-nowrap">ELECTRIX METER INFO</th>
                                                    <th class="whitespace-nowrap" colspan="2">METER RECORDS</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr class="intro-x">
                                                    <td class="w-20">
                                                        {{ $i++ }}
                                                    </td>
                                                    <td colspan="2">
                                                        <div class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                                <div class="truncate sm:whitespace-normal flex items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">Meter Owner:</strong>
                                                                        @if($metertype == 'wasac')
                                                                            {{ $selected_meter }}
                                                                        @elseif($metertype == 'electrix')
                                                                            {{ $selected_meter->wasacmeter->client->firstname . " " . $selected_meter->wasacmeter->client->middlename . " " . $selected_meter->wasacmeter->client->lastname}}
                                                                        @endif
                                                                    </span>
                                                                </div>
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">Phone:</strong>+25{{ $selected_meter->wasacmeter->client->phone }}</span>
                                                                </div>
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12H3m18 0h-1.5m-15 3.75H3m18 0h-1.5M8.25 19.5V21M12 3v1.5m0 15V21m3.75-18v1.5m0 15V21m-9-1.5h10.5a2.25 2.25 0 002.25-2.25V6.75a2.25 2.25 0 00-2.25-2.25H6.75A2.25 2.25 0 004.5 6.75v10.5a2.25 2.25 0 002.25 2.25zm.75-12h9v9h-9v-9z" />
                                                                    </svg>

                                                                    <span><strong class="mr-3 font-medium">Meter N<sup>o</sup>:</strong>{{ $selected_meter->wasacmeter->wasac_meter_number }}</span>
                                                                </div>
                                                                <h4 class="font-bold text-gray-500 mt-2">Meter Location</h4>
                                                                <hr width="95px" class="mb-1">
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">Province:</strong>{{ $selected_meter->wasacmeter->province->province }}</span>
                                                                </div>
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">District:</strong>{{ $selected_meter->wasacmeter->district->district }}</span>
                                                                </div>
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">Sector:</strong>{{ $selected_meter->wasacmeter->sector->sector }}</span>
                                                                </div>
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">Cell:</strong>{{ $selected_meter->wasacmeter->cell->cell }}</span>
                                                                </div>
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">Village:</strong>{{ $selected_meter->wasacmeter->village->village }}</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                                @if($electrix_meters == null)
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12H3m18 0h-1.5m-15 3.75H3m18 0h-1.5M8.25 19.5V21M12 3v1.5m0 15V21m3.75-18v1.5m0 15V21m-9-1.5h10.5a2.25 2.25 0 002.25-2.25V6.75a2.25 2.25 0 00-2.25-2.25H6.75A2.25 2.25 0 004.5 6.75v10.5a2.25 2.25 0 002.25 2.25zm.75-12h9v9h-9v-9z" />
                                                                    </svg>

                                                                    <span><strong class="mr-3 font-medium">Meter N<sup>o</sup>:</strong>{{ $selected_meter->electrix_meter_number }}</span>
                                                                </div>
                                                                @else
                                                                    @foreach ($electrix_meters as $item)
                                                                        <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12H3m18 0h-1.5m-15 3.75H3m18 0h-1.5M8.25 19.5V21M12 3v1.5m0 15V21m3.75-18v1.5m0 15V21m-9-1.5h10.5a2.25 2.25 0 002.25-2.25V6.75a2.25 2.25 0 00-2.25-2.25H6.75A2.25 2.25 0 004.5 6.75v10.5a2.25 2.25 0 002.25 2.25zm.75-12h9v9h-9v-9z" />
                                                                            </svg>

                                                                            <span><strong class="mr-3 font-medium">Meter N<sup>o</sup>:</strong>{{ $item->electrix_meter_number }}</span>
                                                                        </div>
                                                                    @endforeach
                                                                @endif
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td colspan="2">
                                                        <div class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">

                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">Last Readings:</strong>{{ $meterrecords->previous_invoice_readings }} <strong>m<sup>3</sup></strong></span>
                                                                </div>
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">Current Readings:</strong>{{ $meterrecords->current_invoice_readings }} <strong>m<sup>3</sup></strong></span>
                                                                </div>
                                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 mr-2">
                                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z" />
                                                                    </svg>
                                                                    <span><strong class="mr-3 font-medium">Unpaid Invoice:</strong>{{ $meterrecords->unpaid_invoice_readings }} <strong>m<sup>3</sup></strong></span>
                                                                </div>

                                                                <div class="truncate sm:whitespace-normal flex mt-5 items-center" wire:click="showSales">
                                                                    <button type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary md:w-60 w-full mr-2 mb-2 ml-2">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 report-box__icon text-white">
                                                                            <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88" />
                                                                        </svg>
                                                                        <span class="ml-2"><a href="javascript:;" data-toggle="modal" data-target="#static-backdrop-modal-preview">Sales History</a></span>
                                                                        {{-- div class="text-center"> <a href="javascript:;" data-toggle="modal" data-target="#static-backdrop-modal-preview" class="btn btn-primary">Show Modal</a> </div> --}}
                                                                    </button>
                                                                </div>


                                                            </div>
                                                        </div>
                                                    </td>

                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- END: Data List -->
                                </div>
                            </section>

                        @endif
                    </div>
                @endif

            </div>
            <!-- END: General Report -->
        </div>
    </div>
</div>