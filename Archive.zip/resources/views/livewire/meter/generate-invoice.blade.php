<div class="content" id="centered">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="save">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Generate Invoice</h2>
                    </div>

                    <div class="intro-y box mt-5">

                        <div id="inline-form" class="p-5">
                            <div class="flex flex-wrap -mx-3 mb-2">
                                <div class="w-full md:w-full px-3 md:mb-0">
                                    <div>
                                        <select style="height: 51px" id="input-state-3" wire:model="selection" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700
                                            py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('selection') border-theme-6 @elseif($selection != "") border-theme-9 @enderror"
                                        >
                                            <option value="" selected>-- Select Action --</option>
                                            <option value="External">External Invoice</option>
                                            <option value="Normal">Regular Invoice</option>
                                            <option value="Override">Override Invoice</option>
                                        </select>
                                        @error('selection')
                                            <div class="text-theme-6 mt-2">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            @if($setMeterNumber)
                                <div class="flex flex-wrap -mx-3 mb-2">

                                    <div class="w-full md:w-1/3 px-3">
                                        <x-simple-select
                                            name="mobile_user"
                                            id="mobile_user"
                                            :options="$mobile_users"
                                            value-field='phone'
                                            text-field='phone'
                                            placeholder="Select User"
                                            search-input-placeholder="Select User"
                                            :searchable="true"
                                            id="input-state-3"
                                            wire:model="mobile_user"
                                            class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        />
                                        @error('mobile_user')
                                            <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="w-full md:w-1/3 px-3">
                                        <x-simple-select
                                            name="reg_meter"
                                            id="reg_meter"
                                            :options="$reg_meters"
                                            value-field='meter_number'
                                            text-field='meter_number'
                                            placeholder="Select Reg Meter"
                                            search-input-placeholder="Select Reg Meter"
                                            :searchable="true"
                                            id="input-state-3"
                                            wire:model="reg_meter"
                                            class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        />
                                        @error('reg_meter')
                                            <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="w-full md:w-1/3 px-3">
                                        <x-simple-select
                                            name="electrix_meter"
                                            id="electrix_meter"
                                            :options="$electrix_meters"
                                            value-field='meter_number'
                                            text-field='meter_number'
                                            placeholder="Select Electrix Meter"
                                            search-input-placeholder="Select Electrix Meter"
                                            :searchable="true"
                                            id="input-state-3"
                                            wire:model="electrix_meter"
                                            class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        />
                                        @error('electrix_meter')
                                            <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="w-full md:w-1/6 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Cost (Frw)</label>
                                            <input id="input-state-1" wire:model="cost" type="number" class="form-control @error('cost') border-theme-6 @elseif($cost != "") border-theme-9 @enderror" placeholder="Cost...">
                                            @error('cost')
                                                <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/6 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Units (Kwh)</label>
                                            <input id="input-state-1" wire:model="units" type="text" class="form-control @error('units') border-theme-6 @elseif($units != "") border-theme-9 @enderror" placeholder="Units...">
                                            @error('units')
                                                <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Reg Token</label>
                                            <input id="input-state-1" wire:model="reg_token" type="text" class="form-control @error('reg_token') border-theme-6 @elseif($reg_token != "") border-theme-9 @enderror" placeholder="Reg Token...">
                                            @error('reg_token')
                                                <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Electrix Token</label>
                                            <input id="input-state-1" wire:model="electrix_token" type="text" class="form-control @error('electrix_token') border-theme-6 @elseif($electrix_token != "") border-theme-9 @enderror" placeholder="Electrix Token...">
                                            @error('electrix_token')
                                                <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>

                                <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end">
                                        <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 mt-5 mr-2 mb-2"> Submit <div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                                </div>
                            @else
                                <div class="flex flex-wrap -mx-3 mb-2">
                                    @if($selection == 'External')
                                        <div class="w-full md:w-3/12 px-3">
                                            <x-simple-select
                                                name="mobile_user"
                                                id="mobile_user"
                                                :options="$mobile_users"
                                                value-field='phone'
                                                text-field='phone'
                                                placeholder="Select User"
                                                search-input-placeholder="Select User"
                                                :searchable="true"
                                                id="input-state-3"
                                                wire:model="mobile_user"
                                                class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            />
                                            @error('mobile_user')
                                                <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="w-full md:w-2/12 px-3 mb-6 md:mb-0">
                                            <div class="md:mr-2">
                                                <input style="height: 51px" id="input-state-1" wire:model="cost" type="number" class="mt-1 form-control @error('cost') border-theme-6 @elseif($cost != "") border-theme-9 @enderror" placeholder="Cost...">
                                                @error('cost')
                                                    <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                         <div class="w-full md:w-2/12 px-3 mb-6 md:mb-0">
                                            <div class="md:mr-2">
                                                <input style="height: 51px" id="input-state-1" wire:model="units" type="text" class="mt-1 form-control @error('units') border-theme-6 @elseif($units != "") border-theme-9 @enderror" placeholder="Units...">
                                                @error('units')
                                                    <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="w-full md:w-5/12 px-3 mb-6 md:mb-0">
                                            <div class="md:mr-2">
                                                <input style="height: 51px" id="input-state-1" wire:model="reg_token" type="text" class="mt-1 form-control @error('reg_token') border-theme-6 @elseif($reg_token != "") border-theme-9 @enderror" placeholder="Reg Token..." maxlength="20">
                                                @error('reg_token')
                                                    <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="w-full md:w-4/12 px-3 mb-6 md:mb-0">
                                            <div class="md:mr-2">
                                                <input style="height: 51px" id="input-state-1" wire:model="meterNumber" type="number" class="mt-1 form-control @error('meterNumber') border-theme-6 @elseif($meterNumber != "") border-theme-9 @enderror" placeholder="Eelctrix Meter Number...">
                                                @error('meterNumber')
                                                    <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="w-full md:w-6/12 px-3 mb-6 md:mb-0">
                                            <div class="md:mr-2">
                                                <input style="height: 51px" id="input-state-1" wire:model="electrix_token" type="text" class="mt-1 form-control @error('electrix_token') border-theme-6 @elseif($electrix_token != "") border-theme-9 @enderror" placeholder="Electrix Token..." @if($externalDisable) disabled @endif>
                                                @error('electrix_token')
                                                    <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                    @else
                                        <div class="w-full md:w-4/12 px-3">
                                            <x-simple-select
                                                name="mobile_user"
                                                id="mobile_user"
                                                :options="$mobile_users"
                                                value-field='phone'
                                                text-field='phone'
                                                placeholder="Select User"
                                                search-input-placeholder="Select User"
                                                :searchable="true"
                                                id="input-state-3"
                                                wire:model="mobile_user"
                                                class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            />
                                            @error('mobile_user')
                                                <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                            @enderror
                                        </div>

                                        <div class="w-full md:w-6/12 px-3 mb-6 md:mb-0">
                                            <div class="md:mr-2">
                                                <input style="height: 51px" id="input-state-1" wire:model="meterNumber" type="text" class="mt-1 form-control @error('meterNumber') border-theme-6 @elseif($cost != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                @error('meterNumber')
                                                    <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                    @endif
                                    <div wire:click="addMeterNumber" id="input-state"  class="p-5 flex flex-wrap items-end justify-end" style="margin-top: -2.5%">
                                            <button type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 mt-5 mr-2 mb-2"> @if($selection == 'External') Submit @else Search @endif<div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                                    </div>

                                </div>
                            @endif

                        </div>

                    </div>

                </div>
            </form>
        </div>

    </div>
</div>