<div class="content" id="centered">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="save">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Meter Sale Registration</h2>
                    </div>

                    <div class="intro-y box mt-5">

                        <div id="inline-form" class="p-5">
                            <section class="mb-2">
                                @if($client != null)
                                <div class="flex flex-wrap -mx-3 mb-2">

                                    <div class="w-full md:w-4/12 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2 md:mt-1">
                                            <span style="text-transform: capitalize"> <strong>Customer Name: </strong> {{ $clientInfo->firstname ." ". $clientInfo->middlename ." ". $clientInfo->lastname }}</span>
                                        </div>
                                    </div>

                                    <div class="w-full md:w-3/12 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2 md:mt-1">
                                            <span> <strong>Phone Number: </strong> +25{{ $clientInfo->phone }}</span>
                                        </div>
                                    </div>

                                    <div class="w-full md:w-5/12 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2 md:mt-1">
                                            <span> <strong>Address: </strong> {{ $clientInfo->address->province->province ." ~ ". $clientInfo->address->sector->sector ." ~ ". $clientInfo->address->cell->cell ." ~ ". $clientInfo->address->village->village }}</span>
                                        </div>
                                    </div>
                                </div>
                                @endif
                            </section>

                            <div class="flex flex-wrap -mx-3 mb-2">

                                <div class="w-full @if($total_sales != "") md:w-8/12 @else md:w-full @endif px-3">
                                    <x-simple-select
                                        name="client"
                                        id="client"
                                        :options="$clients"
                                        value-field='id'
                                        text-field='name'
                                        placeholder="Select User"
                                        search-input-placeholder="Select User"
                                        :searchable="true"
                                        id="input-state-3"
                                        wire:model="client"
                                        class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    />
                                    @error('client')
                                        <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                    @enderror
                                </div>
                                @if($total_sales != "")
                                    <div class="w-full md:w-4/12 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2 md:mt-1">
                                            <input id="input-state-1" style="height: 50px; font-size: 30px; text-align: center; color: green" wire:model="total_sales" type="number" class="form-control @error('total_sales') border-theme-6 @elseif($total_sales != "") border-theme-9 @enderror" placeholder="0 Frw" disabled>
                                            @error('total_sales')
                                                <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                @endif

                                <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                                    <div class="md:mr-2">
                                        <label for="input-state-1" class="form-label">Meter Cost (Frw)</label>
                                        <input id="input-state-1" wire:model="meter_cost" type="number" class="form-control @error('meter_cost') border-theme-6 @elseif($meter_cost != "") border-theme-9 @enderror" placeholder="Cost per meter...">
                                        @error('meter_cost')
                                            <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                                    <div class="md:mr-2">
                                        <label for="input-state-1" class="form-label">Sold Meters</label>
                                        <input id="input-state-1" wire:model="quantity" type="number" class="form-control @error('quantity') border-theme-6 @elseif($quantity != "") border-theme-9 @enderror" placeholder="Sold Meters...">
                                        @error('quantity')
                                            <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <article class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                                    <div class="md:mr-2">
                                        <label for="input-state-1" class="form-label">Travel Expenses</label>
                                        <input id="input-state-1" wire:model="expenses" type="number" class="form-control @error('expenses') border-theme-6 @elseif($expenses != "") border-theme-9 @enderror" placeholder="Travel Expenses...">
                                        @error('expenses')
                                            <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </article>

                                <section class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                                    <div class="md:mr-2">
                                        <label for="input-state-1" class="form-label">Payment Method</label>
                                        <select id="input-state-3" wire:model="payment_method" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700
                                            py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('payment_method') border-theme-6 @elseif($payment_method != "") border-theme-9 @enderror"
                                        >
                                            <option value="" selected>-- Select Payment Method --</option>
                                            <option value="Cash">Cash</option>
                                            <option value="Momo Pay">Momo Pay</option>
                                            <option value="Loaned">Loaned</option>
                                        </select>
                                        @error('payment_method')
                                            <div class="text-theme-6 mt-2">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </section>
                                @if($payment_method == 'Loaned')
                                    <section class="w-full flex flex-wrap">
                                        <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                            <div class="md:mr-2">
                                                <label for="input-state-1" class="form-label">Loaned Meters</label>
                                                <input id="input-state-1" wire:model="loan" type="number" class="form-control @error('loan') border-theme-6 @elseif($loan != "") border-theme-9 @enderror" placeholder="Loaned Meters...">
                                                @error('loan')
                                                    <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                        <section class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                            <div class="md:mr-2">
                                                <label for="input-state-1" class="form-label">Installment Plan</label>
                                                <select id="input-state-3" wire:model="installment" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700
                                                    py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('installment') border-theme-6 @elseif($installment != "") border-theme-9 @enderror"
                                                >
                                                    <option value="" selected>-- Select Installment Plan --</option>
                                                    @for ($i = 1; $i <= 6; $i++)
                                                        <option value="{{ $i }}">{{ $i>1 ? $i .' Months' : $i .' Month' }}</option>
                                                    @endfor
                                                </select>
                                                @error('installment')
                                                    <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </section>
                                        <section class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                            <div class="md:mr-2">
                                                <label for="input-state-1" class="form-label">Paid Amount</label>
                                                <input id="input-state-1" wire:model="paid_amount" type="number" class="form-control @error('paid_amount') border-theme-6 @elseif($paid_amount != "") border-theme-9 @enderror" placeholder="Paid amount...">
                                                @error('paid_amount')
                                                    <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </section>
                                    </section>
                                    @if($installment != "" && $paid_amount != "")
                                         <div class="w-full">
                                                <!-- BEGIN: Data List -->
                                                <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                                                    <table class="table table-report -mt-2">
                                                        <thead>
                                                            <tr>
                                                                <th class="whitespace-nowrap">S/N</th>
                                                                <th class="whitespace-nowrap">Installments</th>
                                                                <th class="whitespace-nowrap">Amount To Pay</th>
                                                                <th class="text-center whitespace-nowrap">Due Date</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @for($x = 1; $x <= $installment; $x++)
                                                                <tr class="intro-x">
                                                                    <td class="w-20">
                                                                        {{ $x }}
                                                                    </td>
                                                                    <td class="font-bold">
                                                                        @if ($x == 1)
                                                                            {{ $x }}<sup>st</sup> Installment
                                                                        @endif
                                                                        @if($x == 2)
                                                                            {{ $x }}<sup>nd</sup> Installment
                                                                        @endif
                                                                        @if($x == 3)
                                                                            {{ $x }}<sup>rd</sup> Installment
                                                                        @endif
                                                                        @if($x == 4)
                                                                            {{ $x }}<sup>th</sup> Installment
                                                                        @endif
                                                                        @if($x == 5)
                                                                            {{ $x }}<sup>th</sup> Installment
                                                                        @endif
                                                                        @if($x == 6)
                                                                            {{ $x }}<sup>th</sup> Installment
                                                                        @endif
                                                                    </td>
                                                                    <td>
                                                                        {{ round((intVal($total_sales) - intVal($paid_amount))/$installment) }}
                                                                    </td>
                                                                    <td class="table-report__action w-56">
                                                                        <span class="flex justify-center items-center">{{ Carbon\Carbon::now()->addMonth($x)->toDateString() }}</span>
                                                                    </td>

                                                                </tr>
                                                            @endfor
                                                            </tbody>
                                                            <tfoot>
                                                                <tr>
                                                                    <th colspan="2">Total Loan</th>
                                                                    <th></th>
                                                                    <td class="flex justify-center items-center font-bold"> {{ intVal($total_sales) - intVal($paid_amount) }} Frw</td>
                                                                </tr>
                                                            </tfoot>
                                                    </table>
                                                </div>
                                                <!-- END: Data List -->
                                            </div>
                                        </div>
                                    @endif
                                @endif

                            </div>

                            <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end">
                                    <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 mt-5 mr-2 mb-2"> Approve <div wire:loading.delay>d... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                            </div>

                        </div>

                    </div>

                </div>
            </form>
        </div>

    </div>
</div>