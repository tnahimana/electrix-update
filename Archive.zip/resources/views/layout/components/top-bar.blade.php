<!-- BEGIN: Top Bar -->
<div class="top-bar">
    <!-- BEGIN: Breadcrumb -->
    <div class="-intro-x breadcrumb mr-auto hidden sm:flex">
        <a href="#">Electrix vending</a>
        <i data-feather="chevron-right" class="breadcrumb__icon"></i>
        <a href="@yield('navigation-url')" class="breadcrumb--active">@yield('navigation')</a>
    </div>
    <!-- END: Breadcrumb -->
    <!-- BEGIN: Search -->
    <div class="intro-x relative mr-3 sm:mr-6">
        <div class="search hidden sm:block">
        </div>
        <a class="notification sm:hidden" href="">
            <i data-feather="search" class="notification__icon dark:text-gray-300"></i>
        </a>
    </div>
    <!-- END: Search -->
    <!-- BEGIN: Notifications -->
    <div class="intro-x dropdown mr-auto sm:mr-6">
        <div class="dropdown-toggle notification notification--bullet cursor-pointer" role="button" aria-expanded="false">
            <i data-feather="bell" class="notification__icon dark:text-gray-300"></i>
        </div>
    </div>
    <!-- END: Notifications -->
    <!-- BEGIN: Account Menu -->
    <div class="intro-x dropdown w-8 h-8">
        <div class="dropdown-toggle w-8 h-8 rounded-full overflow-hidden shadow-lg image-fit zoom-in" role="button" aria-expanded="false">
            <img alt="Rubick Tailwind HTML Admin Template" 
            @if(auth()->user())
                @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                    @if(auth()->user()->admin->image_id != null)
                        src="{{ auth()->user()->admin->image->img_url }}"
                    @else
                        src="{{ asset('dist/images/' . $fakers[9]['photos'][0]) }}"
                    @endif
                @elseif(auth()->user()->role->name == 'client')
                    @if(auth()->user()->client->image_id != null)
                        src="{{ auth()->user()->client->image->img_url }}"
                    @else
                        src="{{ asset('dist/images/' . $fakers[9]['photos'][0]) }}"
                    @endif
                @elseif(auth()->user()->role->name == 'agent')
                    @if(auth()->user()->agent->image_id != null)
                        src="{{ auth()->user()->agent->image->img_url }}"
                    @else
                        src="{{ asset('dist/images/' . $fakers[9]['photos'][0]) }}"
                    @endif
                @endif
            @else 
                src="{{ asset('dist/images/' . $fakers[9]['photos'][0]) }}"
            @endif
            >
        </div>
        <div class="dropdown-menu w-56">
            <div class="dropdown-menu__content box bg-theme-26 dark:bg-dark-6 text-white">
                <div class="p-4 border-b border-theme-27 dark:border-dark-3">
                    <div class="font-medium">
                       @if(auth()->user()) {{ auth()->user()->email }} @else Anonymous @endif
                    </div>
                    <div class="text-xs text-theme-28 mt-0.5 dark:text-gray-600">@if(auth()->user()) {{ auth()->user()->role->name }} @else User @endif</div>
                </div>
                <div class="p-2">
                    <a 
                    @if(auth()->user())
                    @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                        href="/admins/{{ auth()->user()->admin->id }}"
                    @elseif(auth()->user()->role->name == 'agent')
                        href="/agents/{{ auth()->user()->agent->id }}"
                    @elseif(auth()->user()->role->name == 'client')
                        href="/clients/{{ auth()->user()->client->id }}"
                    @endif
                    @else
                        href="/shop"
                    @endif
                     class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-theme-1 dark:hover:bg-dark-3 rounded-md">
                        <i data-feather="user" class="w-4 h-4 mr-2"></i> Profile
                    </a>
                    <a href="#" class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-theme-1 dark:hover:bg-dark-3 rounded-md">
                        <i data-feather="lock" class="w-4 h-4 mr-2"></i> Reset Password
                    </a>
                </div>
                <div class="p-2 border-t border-theme-27 dark:border-dark-3">
                    <a href="{{ route('logout') }}" class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-theme-1 dark:hover:bg-dark-3 rounded-md">
                        <i data-feather="toggle-right" class="w-4 h-4 mr-2"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- END: Account Menu -->
</div>
<!-- END: Top Bar -->