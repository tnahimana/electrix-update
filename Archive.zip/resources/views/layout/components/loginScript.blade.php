<script src="{{ asset('app-assets/vendors/js/vendors.min.js') }}"></script>
