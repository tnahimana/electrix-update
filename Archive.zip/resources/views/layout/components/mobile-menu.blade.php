<!-- BEGIN: Mobile Menu -->
        <div class="mobile-menu md:hidden">
            <div class="mobile-menu-bar">
                <a href="/dashboard" class="flex mr-auto">
                    <img alt="Electrix Vending" class="w-6" src="{{ asset('dist/images/logo.svg') }}">
                </a>
                <a href="javascript:;" id="mobile-menu-toggler"> <i data-feather="bar-chart-2" class="w-8 h-8 text-white transform -rotate-90"></i> </a>
            </div>
            @if (auth()->user())
            <ul class="border-t border-theme-29 py-5 hidden">
                <li>
                    <a href="javascript:;" class="menu">
                        <div class="menu__icon"> <i data-feather="home"></i> </div>
                        <div class="menu__title"> Dashboard <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
                    </a>
                    <ul class="">
                            <li>
                                <a href="/energy-dashboard" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Energy Dashboard </div>
                                </a>
                            </li>
                            @if(auth()->user()->role->name == 'super_admin')
                                <li>
                                    <a href="/water-dashboard" class="menu">
                                        <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="menu__title"> Water Dashboard </div>
                                    </a>
                                </li>
                            @endif
                        </ul>
                </li>
                @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-feather="users"></i> </div>
                            <div class="menu__title"> Admins <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/admins" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Admins </div>
                                </a>
                            </li>
                            @if(auth()->user()->role->name == 'super_admin')
                                <li>
                                    <a href="/admins/create" class="menu">
                                        <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="menu__title"> Add Admin </div>
                                    </a>
                                </li>
                            @endif
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-feather="user-check"></i> </div>
                            <div class="menu__title"> Agents <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/agents" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Agents </div>
                                </a>
                            </li>
                            <li>
                                <a href="/agents/create" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Add Agent </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-feather="key"></i> </div>
                            <div class="menu__title"> Update Versions <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/updates" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Update Versions </div>
                                </a>
                            </li>
                            <li>
                                <a href="/updates/create" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Release  Update </div>
                                </a>
                            </li>
                            <li>
                                <a href="/upload-app" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Release  App </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endif
                @if(auth()->user()->role->name != 'client')
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-feather="zap"></i> </div>
                            <div class="menu__title"> Meter Actions <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/meters" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Meter Actions </div>
                                </a>
                                @if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin')
                                    <a href="/transactions" class="menu">
                                        <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="menu__title"> Transactions </div>
                                    </a>
                                    <a href="/fdi-transactions" class="menu">
                                        <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="menu__title"> FDI transactions </div>
                                    </a>
                                    <a href="/electrix-sales" class="menu">
                                        <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="menu__title"> Electrix Sales </div>
                                    </a>
                                    <a href="/generate-invoice" class="menu">
                                        <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="menu__title"> Generate Invoice </div>
                                    </a>
                                @endif
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-feather="user-check"></i> </div>
                            <div class="menu__title"> Clients <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/clients" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Clients  </div>
                                </a>
                            </li>
                            <li>
                                <a href="/clients/create" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Add Client  </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endif
                 @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-feather="shopping-bag"></i> </div>
                            <div class="menu__title"> Sales Info <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/register-meter-sale" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Register Sale  </div>
                                </a>
                            </li>
                            <li>
                                <a href="/revenue-records" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Revenue Records  </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-feather="monitor"></i> </div>
                            <div class="menu__title"> Schedules <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/scheduled-sales" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Scheduled Sales  </div>
                                </a>
                            </li>
                            <li>
                                <a href="/revenue-records" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Revenue Records  </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="menu">
                            <div class="menu__icon"> <i data-feather="unlock"></i> </div>
                            <div class="menu__title"> Password Reset <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/password-reset" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Password Reset  </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endif
            </ul>
            @endif
        </div>
        <!-- END: Mobile Menu -->
<!-- END: Mobile Menu -->
