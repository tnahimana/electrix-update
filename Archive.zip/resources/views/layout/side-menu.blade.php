@extends('../layout/main')

@section('head')
    <title>@yield('title')</title>
@endsection

@section('content')
    @include('../layout/components/mobile-menu')
    <div class="flex">
        <!-- BEGIN: Side Menu -->
        <nav class="side-nav">
            <a href="/dashboard" class="intro-x flex items-center pl-5 pt-4">
                <img alt="Electrix Vending" class="w-6" src="{{ asset('dist/images/logo.svg') }}">
                <span class="hidden xl:block text-white text-lg ml-3">
                    <strong>Ele</strong><span class="font-medium">trix</span>
                </span>
            </a>
            <div class="side-nav__devider my-6"></div>
            <ul>
                <li>
                    <a href="javascript:;.html" class="side-menu @yield('active-dashboard')">
                        <div class="side-menu__icon"> <i data-feather="home"></i> </div>
                        <div class="side-menu__title">
                            Dashboard
                            <div class="side-menu__sub-icon transform rotate-180"> <i data-feather="chevron-down"></i> </div>
                        </div>
                    </a>
                    <ul class="">
                        <li>
                            <a href="/dashboard" class="side-menu side-menu--active">
                                <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                <div class="side-menu__title"> Dashboard </div>
                            </a>
                        </li>
                        <li>
                            <a href="/energy-dashboard" class="side-menu">
                                <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                <div class="side-menu__title"> Energy Dashboard </div>
                            </a>
                        </li>
                        <li>
                            <a href="/water-dashboard" class="side-menu">
                                <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                <div class="side-menu__title"> Water Dashboard </div>
                            </a>
                        </li>
                    </ul>
                </li>
                @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-admin')">
                            <div class="side-menu__icon"> <i data-feather="users"></i> </div>
                            <div class="side-menu__title">
                                Admins
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/admins" class="side-menu">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Admins </div>
                                </a>
                            </li>
                            @if(auth()->user()->role->name == 'super_admin')
                                <li>
                                    <a href="/admins/create" class="side-menu">
                                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="side-menu__title"> Add Admin </div>
                                    </a>
                                </li>
                            @endif
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-agent')">
                            <div class="side-menu__icon"> <i data-feather="user-check"></i> </div>
                            <div class="side-menu__title">
                                Agents
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/agents" class="side-menu @yield('active-agent')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Agents </div>
                                </a>
                            </li>
                            <li>
                                <a href="/agents/create" class="side-menu @yield('active-agent')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Add Agent </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-meters')">
                            <div class="side-menu__icon"> <i data-feather="zap" class="block mx-auto"></i>  </div>
                            <div class="side-menu__title">
                                Meter Actions
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/meters" class="side-menu @yield('active-meters')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Meter Actions</div>
                                </a>
                                @if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin')
                                    <a href="/fdi-transactions" class="side-menu @yield('active-meters')">
                                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="side-menu__title"> FDI transactions</div>
                                    </a>
                                    <a href="/electrix-sales" class="side-menu @yield('active-meters')">
                                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="side-menu__title"> Electrix Sales</div>
                                    </a>
                                    <a href="/generate-invoice" class="side-menu @yield('active-meters')">
                                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="side-menu__title"> Generate Invoice</div>
                                    </a>
                                @endif
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-shortcode')">
                            <div class="side-menu__icon"> <i data-feather="key" class="block mx-auto"></i>  </div>
                            <div class="side-menu__title">
                                Update Versions
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/updates" class="side-menu @yield('active-shortcode')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Update Versions</div>
                                </a>
                            </li>
                            <li>
                                <a href="/updates/create" class="side-menu @yield('active-shortcode')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Release  Update </div>
                                </a>
                            </li>
                            <li>
                                <a href="/upload-app" class="side-menu @yield('active-shortcode')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Release  App </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endif
                @if(auth()->user()->role->name == 'agent')
                 <li>
                    <a href="javascript:;" class="side-menu @yield('active-meters')">
                        <div class="side-menu__icon"> <i data-feather="zap" class="block mx-auto"></i>  </div>
                        <div class="side-menu__title">
                            Meter Actions
                            <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                        </div>
                    </a>
                    <ul class="">
                        <li>
                            <a href="/meters" class="side-menu @yield('active-meters')">
                                <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                <div class="side-menu__title"> Meter Actions</div>
                            </a>
                        </li>
                    </ul>
                </li>
                @endif
                @if(auth()->user()->role->name != 'client')
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-client')">
                            <div class="side-menu__icon"> <i data-feather="user-check"></i> </div>
                            <div class="side-menu__title">
                                Clients
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/clients" class="side-menu @yield('active-client')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Clients </div>
                                </a>
                            </li>
                            @if(auth()->user()->role->name != 'client')
                            <li>
                                <a href="/clients/create" class="side-menu @yield('active-client')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Add Client </div>
                                </a>
                            </li>
                            @endif
                        </ul>

                    </li>
                @endif
                @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-sale')">
                            <div class="side-menu__icon"> <i data-feather="shopping-bag"></i> </div>
                            <div class="side-menu__title">
                                Sales Info
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/register-meter-sale" class="side-menu @yield('active-sale')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Register Sale </div>
                                </a>
                            </li>
                            <li>
                                <a href="/revenue-records" class="side-menu @yield('active-sale')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Revenue Records </div>
                                </a>
                            </li>
                        </ul>

                    </li>
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-schedule')">
                            <div class="side-menu__icon"> <i data-feather="monitor"></i> </div>
                            <div class="side-menu__title">
                                Schedules
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/scheduled-sales" class="side-menu @yield('active-schedule')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Scheduled Sales</div>
                                </a>
                            </li>
                            <li>
                                <a href="/schedule-sale" class="side-menu @yield('active-schedule')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Schedule Sale </div>
                                </a>
                            </li>
                        </ul>

                    </li>
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-user')">
                            <div class="side-menu__icon"> <i data-feather="unlock"></i> </div>
                            <div class="side-menu__title">
                                Password Reset
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/password-reset" class="side-menu @yield('active-schedule')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Reset Password</div>
                                </a>
                            </li>
                        </ul>

                    </li>
                @endif
            </ul>
        </nav>
        <!-- END: Side Menu -->
        <!-- BEGIN: Content -->
        <div class="content">
            @include('../layout/components/top-bar')
            @yield('subcontent')
        </div>
        <!-- END: Content -->
    </div>
@endsection