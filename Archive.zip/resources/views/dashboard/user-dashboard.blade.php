@extends('../layout/' . $layout)

@section('title')
    Dashboard
@endsection

@section('active-dashboard')
    side-menu--active
@endsection

@section('navigation')
    Dashboard
@endsection

@section('navigation-url')
    user-dashboard
@endsection

@section('subcontent')
    @livewire('dashboard.user-dashboard')
@endsection