<?php $__env->startSection('title'); ?>
    Transactions | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-meters'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Transactions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    transactions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('meter.transaction')->html();
} elseif ($_instance->childHasBeenRendered('KRunLYD')) {
    $componentId = $_instance->getRenderedChildComponentId('KRunLYD');
    $componentTag = $_instance->getRenderedChildComponentTagName('KRunLYD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KRunLYD');
} else {
    $response = \Livewire\Livewire::mount('meter.transaction');
    $html = $response->html();
    $_instance->logRenderedChild('KRunLYD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/meter/transactions.blade.php ENDPATH**/ ?>