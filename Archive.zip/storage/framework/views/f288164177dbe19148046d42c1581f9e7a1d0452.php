<?php $__env->startSection('title'); ?>
    Dashbaord | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashbaord'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
   Water Dashbaord
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    water-dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.water-dashboard')->html();
} elseif ($_instance->childHasBeenRendered('Y1dCu5h')) {
    $componentId = $_instance->getRenderedChildComponentId('Y1dCu5h');
    $componentTag = $_instance->getRenderedChildComponentTagName('Y1dCu5h');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Y1dCu5h');
} else {
    $response = \Livewire\Livewire::mount('dashboard.water-dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('Y1dCu5h', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/water/dashbaord.blade.php ENDPATH**/ ?>