<?php $__env->startSection('title'); ?>
    Client Info | Electrix Vending
<?php $__env->stopSection(); ?>
<?php $__env->startSection('active-client'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Client Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    <?php echo e($client->id); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-client'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('client.client-show', ['id' => $client->id])->html();
} elseif ($_instance->childHasBeenRendered('paQVazY')) {
    $componentId = $_instance->getRenderedChildComponentId('paQVazY');
    $componentTag = $_instance->getRenderedChildComponentTagName('paQVazY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('paQVazY');
} else {
    $response = \Livewire\Livewire::mount('client.client-show', ['id' => $client->id]);
    $html = $response->html();
    $_instance->logRenderedChild('paQVazY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/client/show.blade.php ENDPATH**/ ?>