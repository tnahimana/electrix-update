<?php $__env->startSection('title'); ?>
    Login | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.login')->html();
} elseif ($_instance->childHasBeenRendered('TsxIhm2')) {
    $componentId = $_instance->getRenderedChildComponentId('TsxIhm2');
    $componentTag = $_instance->getRenderedChildComponentTagName('TsxIhm2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TsxIhm2');
} else {
    $response = \Livewire\Livewire::mount('auth.login');
    $html = $response->html();
    $_instance->logRenderedChild('TsxIhm2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/auth/login.blade.php ENDPATH**/ ?>