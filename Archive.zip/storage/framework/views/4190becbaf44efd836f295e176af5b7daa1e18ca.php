<?php $__env->startSection('title'); ?>
    Scheduled Sales | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-schedule'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Scheduled Sales
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    scheduled-sales
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('schedule.schedule-index')->html();
} elseif ($_instance->childHasBeenRendered('46kC01O')) {
    $componentId = $_instance->getRenderedChildComponentId('46kC01O');
    $componentTag = $_instance->getRenderedChildComponentTagName('46kC01O');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('46kC01O');
} else {
    $response = \Livewire\Livewire::mount('schedule.schedule-index');
    $html = $response->html();
    $_instance->logRenderedChild('46kC01O', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/schedule/index.blade.php ENDPATH**/ ?>