<?php $__env->startSection('title'); ?>
    FDI Transactions | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-meters'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    FDI Transactions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    fdi-transactions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('meter.fdi-transactions')->html();
} elseif ($_instance->childHasBeenRendered('Z4IZzhS')) {
    $componentId = $_instance->getRenderedChildComponentId('Z4IZzhS');
    $componentTag = $_instance->getRenderedChildComponentTagName('Z4IZzhS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Z4IZzhS');
} else {
    $response = \Livewire\Livewire::mount('meter.fdi-transactions');
    $html = $response->html();
    $_instance->logRenderedChild('Z4IZzhS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/meter/fdi-transactions.blade.php ENDPATH**/ ?>