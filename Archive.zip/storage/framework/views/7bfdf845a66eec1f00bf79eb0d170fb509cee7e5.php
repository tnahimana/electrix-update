<?php $__env->startSection('title'); ?>
    FDI Transactions | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-meters'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    FDI Transactions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    fdi-transactions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('meter.fdi-transactions')->html();
} elseif ($_instance->childHasBeenRendered('BImYOKi')) {
    $componentId = $_instance->getRenderedChildComponentId('BImYOKi');
    $componentTag = $_instance->getRenderedChildComponentTagName('BImYOKi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BImYOKi');
} else {
    $response = \Livewire\Livewire::mount('meter.fdi-transactions');
    $html = $response->html();
    $_instance->logRenderedChild('BImYOKi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/meter/fdi-transactions.blade.php ENDPATH**/ ?>