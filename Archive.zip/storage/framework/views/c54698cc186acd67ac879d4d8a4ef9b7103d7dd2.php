<?php $__env->startSection('title'); ?>
    Electrix Sales | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-meters'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Electrix Sales
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    electrix-sales
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('revenues.electrix-sales')->html();
} elseif ($_instance->childHasBeenRendered('1yuqSUw')) {
    $componentId = $_instance->getRenderedChildComponentId('1yuqSUw');
    $componentTag = $_instance->getRenderedChildComponentTagName('1yuqSUw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1yuqSUw');
} else {
    $response = \Livewire\Livewire::mount('revenues.electrix-sales');
    $html = $response->html();
    $_instance->logRenderedChild('1yuqSUw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/revenues/electrix-sales.blade.php ENDPATH**/ ?>