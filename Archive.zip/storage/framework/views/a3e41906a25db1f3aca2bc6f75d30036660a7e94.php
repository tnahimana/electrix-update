<div class="grid grid-cols-12 gap-6">
    <div class="col-span-12 2xl:col-span-9">
        <div class="grid grid-cols-12 gap-6">
            
            <!-- BEGIN: General Report -->
            <div class="col-span-12 mt-8">
                <div class="intro-y flex items-center h-10">
                    <h2 class="text-lg font-medium truncate mr-5">
                        Dashboard
                    </h2>
                    <a href="" class="ml-auto flex items-center text-theme-1 dark:text-theme-10"> <i data-feather="refresh-ccw" class="w-4 h-4 mr-3"></i> Reload Data </a>
                </div>
                <div class="grid grid-cols-12 gap-6 mt-5">
                    <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-feather="shopping-cart" class="report-box__icon text-theme-10"></i> 
                                    <div class="ml-auto">
                                        <div class="text-3xl font-medium leading-8">
                                            <?php if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin'): ?>
                                                <?php echo e($sales_admin_energy); ?>

                                            <?php elseif(auth()->user()->role->name == 'agent'): ?>
                                                <?php echo e($sales_agent_energy); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-3xl font-medium leading-8 mt-6">
                                    
                                </div>
                                <div class="text-base text-gray-600 mt-1">Energy Meters</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-feather="shopping-cart" class="report-box__icon text-theme-10"></i> 
                                    <div class="ml-auto">
                                        <div class="text-3xl font-medium leading-8">
                                            <?php if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin'): ?>
                                                <?php echo e($sales_admin_water); ?>

                                            <?php elseif(auth()->user()->role->name == 'agent'): ?>
                                                <?php echo e($sales_agent_water); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-3xl font-medium leading-8 mt-6">
                                    
                                </div>
                                <div class="text-base text-gray-600 mt-1"> Water  Meters</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-feather="credit-card" class="report-box__icon text-theme-11"></i> 
                                    <div class="ml-auto">
                                        <div class="text-3xl font-medium leading-8">
                                            <?php if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin'): ?>
                                                <?php echo e($reg_meters); ?>

                                            <?php elseif(auth()->user()->role->name == 'agent'): ?>
                                                <?php echo e($agent_reg_meters); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-3xl font-medium leading-8 mt-6">
                                    
                                </div>
                                <div class="text-base text-gray-600 mt-1">Reg Meters</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-feather="credit-card" class="report-box__icon text-theme-11"></i> 
                                    <div class="ml-auto">
                                        <div class="text-3xl font-medium leading-8">
                                            <?php if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin'): ?>
                                                <?php echo e($wasac_meters); ?>

                                            <?php elseif(auth()->user()->role->name == 'agent'): ?>
                                                <?php echo e($agent_wasac_meters); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-3xl font-medium leading-8 mt-6">
                                    
                                </div>
                                <div class="text-base text-gray-600 mt-1">Wasac Meters</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-feather="monitor" class="report-box__icon text-theme-12"></i> 
                                    <div class="ml-auto">
                                        <?php if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin'): ?>
                                            <div class="text-3xl font-medium leading-8">    
                                                <?php echo e($agents); ?>

                                            </div>
                                        <?php elseif(auth()->user()->role->name == 'agent'): ?>
                                            <div class="text-xl font-medium leading-8">
                                                <?php echo e($location->address->office_address); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="text-3xl font-medium leading-8 mt-6">
                                    
                                </div>
                                <div class="text-base text-gray-600 mt-1">
                                    <?php if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin'): ?>
                                        Agents
                                    <?php elseif(auth()->user()->role->name == 'agent'): ?>
                                        Agent Location
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-feather="user" class="report-box__icon text-theme-9"></i> 
                                    <div class="ml-auto">
                                        <div class="text-3xl font-medium leading-8">
                                            <?php if(auth()->user()->role->name == "super_admin" || auth()->user()->role->name == "admin"): ?>
                                                <?php echo e($client_admin); ?>

                                            <?php elseif(auth()->user()->role->name == "agent"): ?>
                                                <?php echo e($client_agent); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-3xl font-medium leading-8 mt-6">
                                    
                                </div>
                                <div class="text-base text-gray-600 mt-1">Clients</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END: General Report -->
        </div>
    </div>
</div>
<?php /**PATH /Users/nahimana/Documents/Workspace/electrix-meter/resources/views/livewire/dashboard/dashboard.blade.php ENDPATH**/ ?>