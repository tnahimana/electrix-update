<?php $__env->startSection('title'); ?>
    Revenue Records | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-sale'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Revenue Records
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    revenue-records
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('revenues.revenue-records')->html();
} elseif ($_instance->childHasBeenRendered('YCKl2YW')) {
    $componentId = $_instance->getRenderedChildComponentId('YCKl2YW');
    $componentTag = $_instance->getRenderedChildComponentTagName('YCKl2YW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YCKl2YW');
} else {
    $response = \Livewire\Livewire::mount('revenues.revenue-records');
    $html = $response->html();
    $_instance->logRenderedChild('YCKl2YW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/revenues/revenue-records.blade.php ENDPATH**/ ?>