<?php $__env->startSection('title'); ?>
    Register Sale | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-sale'); ?>
    side-menu--active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
    Register Sale
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation-url'); ?>
    register-meter-sale
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('revenues.sale-register')->html();
} elseif ($_instance->childHasBeenRendered('X2kp2AC')) {
    $componentId = $_instance->getRenderedChildComponentId('X2kp2AC');
    $componentTag = $_instance->getRenderedChildComponentTagName('X2kp2AC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('X2kp2AC');
} else {
    $response = \Livewire\Livewire::mount('revenues.sale-register');
    $html = $response->html();
    $_instance->logRenderedChild('X2kp2AC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/' . $layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/revenues/sale-register.blade.php ENDPATH**/ ?>