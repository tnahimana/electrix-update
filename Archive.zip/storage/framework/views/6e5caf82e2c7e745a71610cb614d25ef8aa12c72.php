<?php $__env->startSection('body'); ?>
    <body class="main">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading-indicator','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loading-indicator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('../layout/components/dark-mode-switcher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- BEGIN: JS Assets-->
        <script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?key=["your-google-map-api"]&libraries=places"></script>
        <script src="<?php echo e(mix('dist/js/app.js')); ?>"></script>
        
        <script src="<?php echo e(asset('dist/js/toast.js')); ?>"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        
        <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
        
        <?php echo \Livewire\Livewire::scripts(); ?>

        <!-- END: JS Assets-->

            <?php if(session()->has('success')): ?>
                <script>
                        toastr.success("<?php echo e(session('success')); ?>").fadeOut(15000);
                </script>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
                <script>
                        toastr.error("<?php echo e(session('error')); ?>").fadeOut(15000);
                </script>
            <?php endif; ?>
            <script>
                $(document).ready(function(){
                    toastr.options = {
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                    }
                    window.addEventListener('hide-form', event => {
                        $('#showmyModal').modal('hide');
                        $('#updatemyModal').modal('hide');
                        $('.modal-backdrop').remove();
                        toast.success(event.detail.message, 'success!');
                    })
                    window.addEventListener('show-form', event => {
                        toast.success(event.detail.message, 'error!');
                        $('.modal-backdrop').remove();
                    })
                })
            </script>
            <script>
                var loader = document.getElementById('preloader');
                window.addEventListener('load', function(){
                    loader.style.display = 'none';
                })
            </script>
            <script>
                var loader = document.getElementById('loader');
                window.addEventListener('load', function(){
                    loader.style.display = 'none';
                })
            </script>
            

            <?php if(session()->has('success')): ?>
                <script>
                    swal({
                        title: "Success!",
                        text: "<?php echo e(session('success')); ?>",
                        icon: "success",
                        button: "Close",
                    });
                </script>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
                <script>
                    swal({
                        title: "Oops, Error!",
                        text: "<?php echo e(session('error')); ?>",
                        icon: "error",
                        button: "Close",
                    });
                </script>
            <?php endif; ?>

            <script>
                let timeoutId;

                function resetTimer() {
                    clearTimeout(timeoutId);
                    timeoutId = setTimeout(() => {
                        window.location.reload();
                    }, 600000); // 10 minutes in milliseconds
                }
                // Add event listeners to reset timer on user activity
                document.addEventListener("mousemove", resetTimer);
                document.addEventListener("keydown", resetTimer);
                document.addEventListener("mousedown", resetTimer);
                document.addEventListener("touchstart", resetTimer);

            </script>

            <script>
                window.addEventListener('custom-event', (event) => {
                    console.log(event.detail.error); // Output: "some data"
                });
            </script>

             <script>
                window.addEventListener('show-error', event => {
                alert('No Pending Transaction Found, Check the entered phone number!');
            })
            </script>

            <script>
                $(document).on('click',".copy",(ev)=>{
                let textArea = 
                ev.target.closest('tr').querySelector('.textArea');
                let selection = window.getSelection();
                let range =  document.createRange();
                range.selectNodeContents(textArea);
                selection.removeAllRanges();
                selection.addRange(range);
                console.dir( range.toString());
                document.execCommand('copy');
                })

            </script>

            <script>
                window.addEventListener('show-delete-confirmation', event => {
                    swal({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this imaginary file!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                    })
                    .then((willDelete) => {
                    if (willDelete) {
                        Livewire.emit('deleteConfirmed');
                    } else {
                        swal("Token Share status change denied!");
                    }
                    });
                })
            </script>

            <script type="text/javascript">
                $('.confirm-button').click(function(event) {
                    var form =  $(this).closest("form");
                    event.preventDefault();
                    swal({
                        title: `Are you sure you want to delete this record?`,
                        text: "It will gone forever",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    })
                        .then((willDelete) => {
                            if (willDelete) {
                                form.submit();
                                 Livewire.emit('deleteSchedule');
                                // deleteSchedule
                            }
                        });
                });
            </script>
    
        <?php echo $__env->yieldContent('script'); ?>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layout/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views////layout/main.blade.php ENDPATH**/ ?>