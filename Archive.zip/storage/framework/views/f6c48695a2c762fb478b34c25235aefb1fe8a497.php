<div class="content" id="centered">
    
    <div class="grid grid-cols-12 gap-6 mt-5" style="width: 100%">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="electrixSave(<?php echo e($owner); ?>)">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y col-span-12 lg:col-span-6">
                        <div id="progressbar-color" class="p-5">
                            <div class="progress mt-3">
                                <div class="progress-bar <?php if($showRegMeter): ?> w-2/4 <?php else: ?> w-full <?php endif; ?>  bg-theme-9" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>

                    <div class="intro-y flex items-center mt-0 border-b border-gray-200 dark:border-dark-5 pb-4">
                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">ADD <?php if($regtype): ?> Energy <?php elseif($wasactype): ?> Water <?php endif; ?> Electrix Meter</h2>
                    </div>

                    <div class="intro-y box mt-5">

                        <div class="flex justify-center items-center sm:ml-4 text-gray-600">
                            <h2 class="text-sm font-medium mr-auto mt-4 ml-6">
                                <?php if($showSelected): ?>
                                Required Electrix Meters
                                <?php elseif($showElectrixMeter): ?>
                                Electrix Meter Information
                                <?php endif; ?>
                            </h2>
                        </div>
                        
                        <div id="inline-form" class="p-5">
                            <?php if($showSelected): ?>
                                <article class="container form-height">
                                    <div class="preview mr-5 ml-5">
                                        
                                        <div class="flex flex-wrap -mx-3 mb-2">

                                            <div class="w-full px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Required Meters</label>
                                                    <select id="input-state-3" wire:model="selected" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 <?php $__errorArgs = ['selected'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($selected != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    >
                                                        <option class="text-center" value="">-- Select Number of Meters --</option>
                                                        <?php for($i = 1; $i <= 10; $i++): ?>
                                                            <option class="text-left text-lg" value="<?php echo e($i); ?>"><?php echo e($i <= 9 ? '0'.$i : $i); ?></option>
                                                        <?php endfor; ?>
                                                        
                                                    </select>
                                                    <?php $__errorArgs = ['selected'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </article>
                            <?php elseif($showElectrixMeter): ?>
                                <main class="container <?php if($selected < 3): ?>form-height <?php endif; ?>">
                                    <div class="preview mr-5 ml-5">
                                        <div class="grid grid-flow-col gap-3">
                                            <div class="col-span-1">

                                                <div class="flex flex-wrap -mx-3 mb-2">
                                                    <div class="w-full md:w-4/5 px-3 mb-6 md:mb-0">
                                                        <div>
                                                            <label for="input-state-3" class="form-label">Required Meters</label>
                                                            <select id="input-state-3" wire:model="selected" class="form-select text-lg text-black box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500" disabled
                                                            >
                                                                <option class="text-center" value="">-- No Required Meters --</option>
                                                                <?php for($i = 1; $i <= 10; $i++): ?>
                                                                    <option class="text-center text-lg" value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                                <?php endfor; ?>
                                                                
                                                            </select>
                                                            <?php $__errorArgs = ['selected'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-span-4">

                                                <div class="flex flex-wrap -mx-3 mb-2">
                                                    <?php if($wasactype): ?>
                                                        <div class="flex flex-wrap -mx-3 mb-2">

                                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                                <div>
                                                                    <label for="input-state-3" class="form-label">Last Invoice <strong>m<sup>3</sup></strong> </label>
                                                                    <input id="input-state-1" wire:model="last_readings" type="text" class="form-control <?php $__errorArgs = ['last_readings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($last_readings != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" maxlength="15">
                                                                    <?php $__errorArgs = ['last_readings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>

                                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                                <div class="md:mr-2">
                                                                    <label for="input-state-1" class="form-label"> Current <strong>m<sup>3</sup></strong></label>
                                                                    <input id="input-state-1" wire:model="current_readings" type="text" class="form-control <?php $__errorArgs = ['current_readings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($current_readings != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" maxlength="15">
                                                                    <?php $__errorArgs = ['current_readings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                    

                                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                                <div>
                                                                    <label for="input-state-3" class="form-label">Unpaid <strong>m<sup>3</sup></strong></</label>
                                                                    <input id="input-state-1" wire:model="unpaid_readings" type="text" class="form-control <?php $__errorArgs = ['unpaid_readings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($unpaid_readings != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" maxlength="15" disabled>
                                                                    <?php $__errorArgs = ['unpaid_readings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="w-full px-3 mb-6 md:mb-0">
                                                        <div class="md:mr-2">
                                                            <label for="input-state-2" class="form-label">Meter Number</label>
                                                                <?php if($selected == 1): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php elseif($selected == 2): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number2 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php elseif($selected == 3): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number2 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number3 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php elseif($selected == 4): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number2 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number3 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number4 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php elseif($selected == 5): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number2 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number3 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number4 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number5 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php elseif($selected == 6): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number2 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number3 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number4 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number5 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number6 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php elseif($selected == 7): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number2 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number3 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number4 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number5 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number6 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number7 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php elseif($selected == 8): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number2 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number3 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number4 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number5 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number6 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number7 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number8" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number8 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php elseif($selected == 9): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number2 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number3 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number4 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number5 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number6 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number7 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number8" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number8 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number9" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number9 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php elseif($selected == 10): ?>
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number1 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number2 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number3 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number4 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number5 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number6 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number7 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number8" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number8 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number9" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number9 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    <input id="input-state-2" wire:model="meter_number10" type="text" class="form-control mt-3 <?php $__errorArgs = ['meter_number10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-theme-6 <?php elseif($meter_number10 != ""): ?> border-theme-9 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Meter Number..." maxlength="11">
                                                                    <?php $__errorArgs = ['meter_number10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="text-theme-6 mt-2"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </main>
                            <?php endif; ?>
                            <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end -mt-2"> 
                                <?php if(!$showSubmit): ?>
                                    <?php if(!$showSelected): ?>        
                                    <button wire:click="previousElectrix" <?php if($hidePrevious): ?> disabled <?php endif; ?> type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-3 pr-3 mt-5 mr-2 mb-2"><i class="fas fa-angle-double-left w-4 h-3 mr-2 text-lg mb-3"></i> Previous  </button>
                                    <?php endif; ?>
                                    <button wire:click="back" type="button" style="background-color: red" class="btn btn-danger pl-3 pr-3 mt-5 mr-2 mb-2"><i class="fas fa-backward w-4 h-3 mr-2 text-lg mb-3"></i> Back  </button>
                                    <button wire:click="nextElectrix" <?php if($hideNext): ?> disabled <?php endif; ?> type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 mt-5 mb-2"> Next <i class="fas fa-angle-double-right w-4 h-3 ml-2 text-lg mb-3"></i></button>
                                <?php else: ?>
                                    <button wire:click="previousElectrix" <?php if($hidePrevious): ?> disabled <?php endif; ?> type="button" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-3 pr-3 mt-5 mr-2 mb-2"><i class="fas fa-angle-double-left w-4 h-3 mr-2 text-lg mb-3"></i> Previous  </button>
                                    <button type="submit" class="btn btn-primary pl-5 pr-5 mt-5 mb-2 pt-5 pb-5 h-10" style="background-color: rgb(17, 17, 134)"> Submit </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                    </div>
                    
                </div>
            </form>
        </div>

    </div>    
</div><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter/resources/views/client/add-meter-electrix.blade.php ENDPATH**/ ?>