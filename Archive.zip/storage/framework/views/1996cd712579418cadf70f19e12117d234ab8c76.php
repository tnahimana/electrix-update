<?php $__env->startSection('title'); ?>
    Login | Electrix Vending
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.login')->html();
} elseif ($_instance->childHasBeenRendered('o3fMZV8')) {
    $componentId = $_instance->getRenderedChildComponentId('o3fMZV8');
    $componentTag = $_instance->getRenderedChildComponentTagName('o3fMZV8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('o3fMZV8');
} else {
    $response = \Livewire\Livewire::mount('auth.login');
    $html = $response->html();
    $_instance->logRenderedChild('o3fMZV8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nahimana/Documents/workspace/electrix-meter/resources/views/auth/login.blade.php ENDPATH**/ ?>