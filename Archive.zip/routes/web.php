<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\APIController;
use Illuminate\Support\Facades\Artisan;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AgentController;
use App\Http\Controllers\WaterController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\EnergyController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\CallbackController;
use App\Http\Controllers\DarkModeController;
use App\Http\Controllers\ExpensesController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\RevenuesController;
use App\Http\Controllers\ScheduleController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ShortcodeController;
use App\Http\Controllers\MeterSalesController;
use App\Http\Controllers\ResetPasswordController;
use App\Http\Controllers\ExecuteSaleScheduleController;

Route::get('dark-mode-switcher', [DarkModeController::class, 'switch'])->name('dark-mode-switcher');

Route::get('/login', [AuthController::class, 'index'])->name('login');
Route::get('/', [AuthController::class, 'home']);
Route::get('/privacy-policy', [AuthController::class, 'privacy']);
Route::get('/playstore-privacy-policy', [AuthController::class, 'privacyPlaystore']);
Route::get('/terms&conditions', [AuthController::class, 'terms']);
Route::get('/apps', [AuthController::class, 'app']);
Route::get('get/{filename}', [AuthController::class, 'getfile']);
Route::get('/shop', [PurchaseController::class, 'dashboard']);
Route::post('/callback', [CallbackController::class, 'handleCallback']);


Route::group(['middleware' => ['auth']], function(){
    Route::get('/logout', [LogoutController::class, 'index'])->name('logout');
    Route::get('/dashboard', [DashboardController::class,'index'])->name('dashboard');
    Route::resource('/admins', AdminController::class);
    Route::resource('/agents', AgentController::class);
    Route::resource('/clients', ClientController::class);
    Route::resource('/meters', APIController::class);
    Route::resource('/updates', ShortcodeController::class);
    Route::get('/water-dashboard', [WaterController::class, 'dashboard']);
    Route::get('/energy-dashboard', [EnergyController::class, 'dashboard']);
    Route::get('/fdi-transactions', [MeterSalesController::class, 'fdiTansactions']);
    Route::get('/transactions', [MeterSalesController::class, 'transaction']);
    Route::get('/generate-invoice', [MeterSalesController::class, 'generateInvoice']);
    Route::get('/upload-app', [MeterSalesController::class, 'uploadApp']);
    Route::get('/register-meter-sale', [RevenuesController::class, 'registerSale']);
    Route::get('/revenue-records', [RevenuesController::class, 'revenueRecords']);
    Route::get('/electrix-sales', [RevenuesController::class, 'ElectrixSales']);
    Route::get('/schedule-sale', [ScheduleController::class, 'scheduleSale']);
    Route::get('/scheduled-sales', [ScheduleController::class, 'scheduledSales']);
    Route::post('/delete-schedule/{id}', [ScheduleController::class, 'deleteSchedule']);
    Route::get('/initiate-schedule', [ExecuteSaleScheduleController::class, 'initiateSchedule']);
    Route::get('/success', [ExecuteSaleScheduleController::class, 'success']);
    Route::get('/error', [ExecuteSaleScheduleController::class, 'error']);
    Route::get('/password-reset', [ResetPasswordController::class, 'index']);
    
});