<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MeterSalesController;
use App\Http\Controllers\MobileUserController;



// Route::post('/login',[MobileUserController::class, 'login']);
// Route::post('/register',[MobileUserController::class, 'register']);

// Route::group(['middleware' => ['auth:sanctum','json']], function(){
//     Route::post('/logout',[MobileUserController::class, 'logout']);
//     Route::get('/user',[MobileUserController::class, 'user']);
//     Route::get('/sales',[MeterSalesController::class, 'sales']);
//     Route::get('/sale/{id}',[MeterSalesController::class, 'sale']);
//     Route::get('/profile',[MobileUserController::class, 'profile']);
//     Route::get('/validate/{id}',[MeterSalesController::class, 'validateMeter']);
//     Route::post('/saleStore',[MeterSalesController::class, 'saleStore']);
//     Route::get('/monthlySales/{id}',[MeterSalesController::class, 'monthlySales']);
//     Route::put('/updateSale/{id}',[MeterSalesController::class, 'saleUpdate']);
//     Route::get('/saleRedirect/{id}',[MeterSalesController::class, 'saleRedirect']);
// });