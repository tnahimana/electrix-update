<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wasac_meters', function (Blueprint $table) {
            $table->id();
            $table->foreignId('client_id')->constrained()->onDelete('cascade');
            $table->string('land_upi')->nullable();
            $table->string('wasac_meter_number');
            $table->unsignedBigInteger('meter_province_id');
            $table->unsignedBigInteger('meter_district_id');
            $table->unsignedBigInteger('meter_sector_id');
            $table->unsignedBigInteger('meter_cell_id');
            $table->unsignedBigInteger('meter_village_id');
            $table->string('meter_street_address');
            $table->string('meter_status')->default('Active');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wasac_meters');
    }
};