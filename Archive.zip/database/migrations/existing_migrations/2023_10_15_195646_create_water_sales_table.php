<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('water_sales', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mobile_user_id')->constrained()->onDelete('cascade');
            $table->foreignId('wasac_meter_id')->constrained()->onDelete('cascade');
            $table->foreignId('electrix_meter_id')->constrained()->onDelete('cascade');
            $table->string('water_meter_token');
            $table->string('token_cost');
            $table->string('units');
            $table->string('commusion_status')->default('Unpaid');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('water_sales');
    }
};