import {YargsFactory} from './build/lib/yargs-factory';

declare const Yargs: ReturnType<typeof YargsFactory>;

export default Yargs;
