module.exports = require('./dist/types').YAMLSeq
require('./dist/legacy-exports').warnFileDeprecation(__filename)
