module.exports = require('./dist/types').YAMLMap
require('./dist/legacy-exports').warnFileDeprecation(__filename)
